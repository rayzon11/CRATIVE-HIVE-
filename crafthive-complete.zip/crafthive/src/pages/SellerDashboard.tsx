import PageLayout from "@/components/PageLayout";
import { useState } from "react";
import { BarChart2, Package, ShoppingBag, DollarSign, Star, Settings, MessageCircle, Tag, Zap, TrendingUp, Plus, Edit, Trash2, Eye, Copy, AlertCircle, ChevronUp, ChevronDown, ArrowUpRight, Truck } from "lucide-react";
import { products } from "@/data/products";

const NAV = [
  { key: "overview", icon: BarChart2, label: "Overview" },
  { key: "products", icon: Package, label: "Products" },
  { key: "orders", icon: ShoppingBag, label: "Orders" },
  { key: "revenue", icon: DollarSign, label: "Revenue" },
  { key: "coupons", icon: Tag, label: "Coupons" },
  { key: "promotions", icon: Zap, label: "Promotions" },
  { key: "messages", icon: MessageCircle, label: "Messages" },
  { key: "reviews", icon: Star, label: "Reviews" },
  { key: "subscription", icon: TrendingUp, label: "Subscription" },
  { key: "settings", icon: Settings, label: "Shop Settings" },
];

const mockOrders = [
  { id: "CH-1042", buyer: "Sarah M.", total: 82.00, status: "processing", items: 2, date: "Apr 2, 2024" },
  { id: "CH-1038", buyer: "Alex K.", total: 65.00, status: "shipped", items: 1, date: "Mar 30, 2024" },
  { id: "CH-1021", buyer: "Emma L.", total: 34.00, status: "delivered", items: 1, date: "Mar 25, 2024" },
  { id: "CH-0998", buyer: "James P.", total: 48.00, status: "pending", items: 1, date: "Mar 20, 2024" },
];

const KPI = ({ label, value, sub, icon: Icon, trend }: { label: string; value: string; sub: string; icon: typeof BarChart2; trend?: number }) => (
  <div className="bg-white rounded-2xl shadow-sm p-5">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs text-muted-foreground font-medium">{label}</p>
        <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>
      </div>
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
        <Icon size={18} className="text-primary" />
      </div>
    </div>
    {trend !== undefined && (
      <div className={`flex items-center gap-1 mt-3 text-xs font-medium ${trend >= 0 ? "text-green-600" : "text-red-500"}`}>
        {trend >= 0 ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
        {Math.abs(trend)}% vs last period
      </div>
    )}
  </div>
);

const SellerDashboard = () => {
  const [tab, setTab] = useState("overview");
  const [period, setPeriod] = useState("30d");
  const myProducts = products.filter((p) => p.sellerId === "bohothreads" || p.sellerId === "claystudio").slice(0, 6);

  return (
    <div className="min-h-screen bg-secondary/20">
      {/* Header */}
      <div className="bg-white border-b border-border sticky top-0 z-40">
        <div className="container mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground text-xs font-black">CH</span>
            </div>
            <span className="font-bold text-foreground">Seller Dashboard</span>
            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-semibold hidden md:block">PRO</span>
          </div>
          <div className="flex items-center gap-3">
            <a href="/" className="text-xs text-muted-foreground hover:text-primary transition-colors flex items-center gap-1">View Shop <ArrowUpRight size={11} /></a>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-52 shrink-0 hidden md:block h-[calc(100vh-56px)] sticky top-14 overflow-y-auto bg-white border-r border-border">
          <nav className="p-3 space-y-0.5">
            {NAV.map(({ key, icon: Icon, label }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${tab === key ? "bg-primary text-primary-foreground font-semibold" : "text-foreground hover:bg-secondary"}`}
              >
                <Icon size={15} /> {label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile tab bar */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border z-40 flex md:hidden overflow-x-auto">
          {NAV.slice(0, 5).map(({ key, icon: Icon, label }) => (
            <button key={key} onClick={() => setTab(key)} className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[10px] shrink-0 ${tab === key ? "text-primary" : "text-muted-foreground"}`}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </div>

        {/* Main */}
        <main className="flex-1 p-4 md:p-6 pb-20 md:pb-6">
          {/* OVERVIEW */}
          {tab === "overview" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-foreground">Overview</h2>
                <div className="flex gap-1 border border-border rounded-xl p-1">
                  {["7d", "30d", "90d"].map((p) => (
                    <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${period === p ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{p}</button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <KPI label="Revenue" value="$1,248" sub="this period" icon={DollarSign} trend={12.4} />
                <KPI label="Orders" value="38" sub="this period" icon={ShoppingBag} trend={8.2} />
                <KPI label="Products" value="12" sub="6 active" icon={Package} trend={0} />
                <KPI label="Rating" value="4.9★" sub="from 127 reviews" icon={Star} trend={2.1} />
              </div>

              {/* Revenue chart mock */}
              <div className="bg-white rounded-2xl shadow-sm p-5">
                <h3 className="font-bold text-foreground mb-4 flex items-center gap-2"><TrendingUp size={16} className="text-primary" /> Revenue Trend</h3>
                <div className="flex items-end gap-2 h-32">
                  {[45, 62, 38, 78, 54, 92, 68, 85, 71, 96, 88, 110, 95, 128].map((h, i) => (
                    <div key={i} className="flex-1 bg-primary/20 rounded-t-lg hover:bg-primary/40 transition-colors relative group" style={{ height: `${(h / 128) * 100}%` }}>
                      <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-foreground text-primary-foreground text-[9px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">${h}</div>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>Mar 1</span><span>Mar 15</span><span>Mar 30</span>
                </div>
              </div>

              {/* Low stock alerts */}
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
                <h3 className="font-semibold text-amber-800 flex items-center gap-2 mb-3"><AlertCircle size={16} /> Low Stock Alerts</h3>
                <div className="space-y-2">
                  {myProducts.filter((p) => p.stock && p.stock < 10).slice(0, 3).map((p) => (
                    <div key={p.id} className="flex items-center gap-3">
                      <img src={p.image} alt={p.name} className="w-9 h-9 rounded-lg object-cover" />
                      <span className="text-sm text-amber-900 flex-1">{p.name}</span>
                      <span className="text-xs font-bold text-amber-700">{p.stock} left</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent orders */}
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                  <h3 className="font-bold text-foreground">Recent Orders</h3>
                  <button onClick={() => setTab("orders")} className="text-xs text-primary hover:underline">View all</button>
                </div>
                <div className="divide-y divide-border">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="flex items-center gap-4 px-5 py-3">
                      <div className="flex-1">
                        <p className="text-sm font-semibold text-foreground">{order.id}</p>
                        <p className="text-xs text-muted-foreground">{order.buyer} · {order.date}</p>
                      </div>
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${order.status === "delivered" ? "bg-green-100 text-green-700" : order.status === "shipped" ? "bg-blue-100 text-blue-700" : order.status === "processing" ? "bg-amber-100 text-amber-700" : "bg-secondary text-muted-foreground"}`}>{order.status}</span>
                      <span className="text-sm font-bold text-foreground w-16 text-right">${order.total.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS */}
          {tab === "products" && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-foreground">Products</h2>
                <button className="flex items-center gap-1.5 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">
                  <Plus size={15} /> Add Product
                </button>
              </div>

              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-border flex gap-2">
                  <input placeholder="Search products…" className="flex-1 px-3 py-2 text-sm border border-border rounded-xl focus:outline-none" />
                  <select className="px-3 py-2 text-sm border border-border rounded-xl focus:outline-none bg-background text-foreground">
                    <option>All Status</option><option>Active</option><option>Draft</option><option>Flagged</option>
                  </select>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/40">
                      <tr>
                        {["Product", "Price", "Stock", "Status", "Actions"].map((h) => (
                          <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {myProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-secondary/20">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                              <div>
                                <p className="font-medium text-foreground line-clamp-1 max-w-[180px]">{p.name}</p>
                                <p className="text-xs text-muted-foreground capitalize">{p.category.replace(/-/g, " ")}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 font-semibold text-foreground">${p.price.toFixed(2)}</td>
                          <td className="px-4 py-3">
                            <span className={`font-semibold ${(p.stock ?? 0) < 5 ? "text-red-500" : (p.stock ?? 0) < 10 ? "text-amber-500" : "text-foreground"}`}>{p.stock ?? 0}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-xs font-semibold bg-green-100 text-green-700 px-2.5 py-1 rounded-full">Active</span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Eye size={14} /></button>
                              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Edit size={14} /></button>
                              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"><Copy size={14} /></button>
                              <button className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"><Trash2 size={14} /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ORDERS */}
          {tab === "orders" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Orders</h2>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-border flex gap-2 flex-wrap">
                  <input placeholder="Search by order ID or buyer…" className="flex-1 min-w-[180px] px-3 py-2 text-sm border border-border rounded-xl focus:outline-none" />
                  <select className="px-3 py-2 text-sm border border-border rounded-xl focus:outline-none bg-background text-foreground">
                    <option>All Status</option><option>Pending</option><option>Processing</option><option>Shipped</option><option>Delivered</option>
                  </select>
                </div>
                <div className="divide-y divide-border">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="p-4 md:p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <span className="font-bold text-foreground">{order.id}</span>
                            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${order.status === "delivered" ? "bg-green-100 text-green-700" : order.status === "shipped" ? "bg-blue-100 text-blue-700" : order.status === "processing" ? "bg-amber-100 text-amber-700" : "bg-secondary text-muted-foreground"}`}>{order.status}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{order.buyer} · {order.date} · {order.items} item(s)</p>
                        </div>
                        <span className="font-bold text-foreground shrink-0">${order.total.toFixed(2)}</span>
                      </div>
                      <div className="flex gap-2 mt-3">
                        {order.status === "processing" && (
                          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground text-xs font-medium rounded-lg hover:bg-primary/90 transition-colors"><Truck size={11} /> Mark Shipped</button>
                        )}
                        <button className="px-3 py-1.5 border border-border text-xs font-medium rounded-lg hover:bg-secondary transition-colors">View Details</button>
                        <button className="px-3 py-1.5 border border-border text-xs font-medium rounded-lg hover:bg-secondary transition-colors">Print Slip</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SUBSCRIPTION */}
          {tab === "subscription" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Subscription</h2>
              <div className="bg-primary rounded-2xl p-5 text-primary-foreground mb-6">
                <p className="text-sm font-medium opacity-80">Current Plan</p>
                <p className="text-3xl font-bold mt-1">PRO</p>
                <p className="text-sm opacity-80 mt-1">$29.99/month · Renews May 1, 2024</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { name: "Free", price: "$0", features: ["10 listings", "8% commission", "Basic shop"], current: false },
                  { name: "Growth", price: "$9.99", features: ["100 listings", "5% commission", "Verified badge", "Analytics PDF"], current: false },
                  { name: "Pro", price: "$29.99", features: ["Unlimited listings", "3% commission", "Homepage feature", "Custom slug", "CSV import/export", "Priority support"], current: true },
                ].map((plan) => (
                  <div key={plan.name} className={`rounded-2xl p-5 border-2 ${plan.current ? "border-primary bg-primary/5" : "border-border bg-white shadow-sm"}`}>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-foreground">{plan.name}</h3>
                      {plan.current && <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full font-semibold">Current</span>}
                    </div>
                    <p className="text-2xl font-bold text-foreground">{plan.price}<span className="text-sm font-normal text-muted-foreground">/mo</span></p>
                    <ul className="mt-4 space-y-1.5">
                      {plan.features.map((f) => (
                        <li key={f} className="text-xs text-muted-foreground flex items-center gap-1.5"><span className="text-primary">✓</span>{f}</li>
                      ))}
                    </ul>
                    {!plan.current && (
                      <button className="w-full mt-4 py-2 text-sm font-medium border border-primary text-primary rounded-xl hover:bg-primary hover:text-primary-foreground transition-colors">
                        {plan.name === "Free" ? "Downgrade" : "Upgrade"}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* REVENUE */}
          {tab === "revenue" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Revenue</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {[{ label: "Gross Revenue", value: "$3,841.00" }, { label: "Commission (3%)", value: "-$115.23" }, { label: "Net Earned", value: "$3,725.77", bold: true }].map(({ label, value, bold }) => (
                  <div key={label} className="bg-white rounded-2xl shadow-sm p-5">
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className={`text-2xl font-bold mt-1 ${bold ? "text-primary" : "text-foreground"}`}>{value}</p>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-border"><h3 className="font-bold text-foreground">Payout History</h3></div>
                <table className="w-full text-sm">
                  <thead className="bg-secondary/40"><tr>{["Date", "Gross", "Commission", "Net", "Status"].map((h) => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>)}</tr></thead>
                  <tbody className="divide-y divide-border">
                    {[["Apr 1, 2024", "$1,248", "$37.44", "$1,210.56", "Paid"], ["Mar 1, 2024", "$984", "$29.52", "$954.48", "Paid"], ["Feb 1, 2024", "$1,609", "$48.27", "$1,560.73", "Paid"]].map(([date, gross, comm, net, status]) => (
                      <tr key={date} className="hover:bg-secondary/20">
                        <td className="px-4 py-3 text-muted-foreground">{date}</td>
                        <td className="px-4 py-3 font-medium text-foreground">{gross}</td>
                        <td className="px-4 py-3 text-red-500">{comm}</td>
                        <td className="px-4 py-3 font-bold text-foreground">{net}</td>
                        <td className="px-4 py-3"><span className="text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-semibold">{status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* COUPONS */}
          {tab === "coupons" && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-foreground">Coupons</h2>
                <button className="flex items-center gap-1.5 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors"><Plus size={15} /> Create Coupon</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[{ code: "SUMMER10", type: "10% off", min: "$30", uses: "24/100", expires: "Jun 30, 2024", active: true }, { code: "FREESHIP", type: "Free shipping", min: "$50", uses: "8/50", expires: "May 15, 2024", active: true }, { code: "WELCOME20", type: "20% off", min: "$0", uses: "50/50", expires: "Expired", active: false }].map((c) => (
                  <div key={c.code} className={`bg-white rounded-2xl shadow-sm p-5 border-2 ${c.active ? "border-primary/20" : "border-border opacity-60"}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <span className="font-mono font-bold text-foreground text-lg">{c.code}</span>
                        <p className="text-sm text-muted-foreground mt-0.5">{c.type} · Min order {c.min}</p>
                      </div>
                      <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${c.active ? "bg-green-100 text-green-700" : "bg-secondary text-muted-foreground"}`}>{c.active ? "Active" : "Inactive"}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Uses: {c.uses}</span><span>Expires: {c.expires}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* PROMOTIONS */}
          {tab === "promotions" && (
            <div>
              <div className="flex items-center justify-between mb-5">
                <h2 className="text-xl font-bold text-foreground">Sponsored Listings</h2>
                <button className="flex items-center gap-1.5 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors"><Zap size={15} /> Boost a Product</button>
              </div>
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-5">
                <p className="text-sm font-semibold text-amber-800">Boost your products to the top of search and category pages!</p>
                <div className="grid grid-cols-3 gap-3 mt-3">
                  {[["7 days", "$2.99"], ["14 days", "$4.99"], ["30 days", "$9.99"]].map(([days, price]) => (
                    <button key={days} className="bg-white border border-amber-200 rounded-xl p-3 text-center hover:border-primary transition-colors">
                      <p className="font-bold text-foreground">{price}</p>
                      <p className="text-xs text-muted-foreground">{days}</p>
                    </button>
                  ))}
                </div>
              </div>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-border"><h3 className="font-bold text-foreground">Active Boosts</h3></div>
                <div className="divide-y divide-border">
                  {myProducts.slice(0, 2).map((p) => (
                    <div key={p.id} className="flex items-center gap-4 px-5 py-4">
                      <img src={p.image} alt={p.name} className="w-12 h-12 rounded-xl object-cover" />
                      <div className="flex-1">
                        <p className="text-sm font-semibold text-foreground">{p.name}</p>
                        <p className="text-xs text-muted-foreground">12 days remaining</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Impressions</p>
                        <p className="text-sm font-bold text-foreground">1,284</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Clicks</p>
                        <p className="text-sm font-bold text-foreground">87</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {tab === "settings" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Shop Settings</h2>
              <div className="bg-white rounded-2xl shadow-sm p-6 space-y-5">
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Shop Name</label>
                  <input defaultValue="BohoThreads" className="w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Shop Description</label>
                  <textarea defaultValue="Creating bohemian textile art from natural fibers." rows={3} className="w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none" />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Shop URL (Pro only)</label>
                  <div className="flex items-center border border-border rounded-xl overflow-hidden">
                    <span className="px-3 py-2.5 bg-secondary text-sm text-muted-foreground border-r border-border">crafthive.com/shop/</span>
                    <input defaultValue="bohothreads" className="flex-1 px-3 py-2.5 text-sm focus:outline-none" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Location</label>
                  <input defaultValue="Austin, TX" className="w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
                </div>
                <button className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Save Changes</button>
              </div>
            </div>
          )}

          {/* MESSAGES */}
          {tab === "messages" && (
            <div className="text-center py-16">
              <MessageCircle size={48} className="text-muted-foreground/30 mx-auto mb-3" />
              <p className="font-bold text-foreground">No messages yet</p>
              <p className="text-sm text-muted-foreground mt-1">Buyer messages will appear here</p>
            </div>
          )}

          {/* REVIEWS */}
          {tab === "reviews" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Reviews</h2>
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="bg-white rounded-2xl shadow-sm p-5 text-center"><p className="text-3xl font-bold text-foreground">4.9</p><div className="flex justify-center mt-1">{[...Array(5)].map((_, i) => <Star key={i} size={14} className="fill-amber-400 text-amber-400" />)}</div><p className="text-xs text-muted-foreground mt-1">Avg rating</p></div>
                <div className="bg-white rounded-2xl shadow-sm p-5 text-center"><p className="text-3xl font-bold text-foreground">127</p><p className="text-xs text-muted-foreground mt-1">Total reviews</p></div>
                <div className="bg-white rounded-2xl shadow-sm p-5 text-center"><p className="text-3xl font-bold text-green-600">96%</p><p className="text-xs text-muted-foreground mt-1">5-star rate</p></div>
              </div>
              <div className="bg-white rounded-2xl shadow-sm divide-y divide-border">
                {[{ author: "Sarah M.", rating: 5, body: "Absolutely stunning! Will order again.", date: "Apr 1, 2024" }, { author: "James K.", rating: 4, body: "Great quality, fast shipping. Minor packaging issue.", date: "Mar 15, 2024" }].map((r, i) => (
                  <div key={i} className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-semibold text-foreground">{r.author}</span>
                          <div className="flex gap-0.5">{[...Array(r.rating)].map((_, j) => <Star key={j} size={11} className="fill-amber-400 text-amber-400" />)}</div>
                          <span className="text-xs text-muted-foreground">{r.date}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{r.body}</p>
                      </div>
                    </div>
                    <button className="mt-3 text-xs text-primary border border-primary/30 px-3 py-1.5 rounded-lg hover:bg-primary/5 transition-colors">Reply</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default SellerDashboard;
