import PageLayout from "@/components/PageLayout";
import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";
import { useState } from "react";
import { SlidersHorizontal, Grid3X3, List, TrendingUp } from "lucide-react";

const SORTS = ["Most popular", "Price: low to high", "Price: high to low", "Newest", "Best rated"];
const CATS = ["All", "Jewelry", "Art", "Home Decor", "Clothing", "Pottery", "Candles", "Vintage"];

const Trending = () => {
  const [sort, setSort] = useState("Most popular");
  const [cat, setCat] = useState("All");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [priceMax, setPriceMax] = useState(200);
  const [filtersOpen, setFiltersOpen] = useState(false);

  let filtered = [...products];
  if (cat !== "All") filtered = filtered.filter((p) => p.category.toLowerCase().replace(/-/g, " ") === cat.toLowerCase() || p.category === cat.toLowerCase().replace(/ /g, "-"));
  filtered = filtered.filter((p) => p.price <= priceMax);
  if (sort === "Most popular") filtered.sort((a, b) => (b.soldCount ?? 0) - (a.soldCount ?? 0));
  else if (sort === "Price: low to high") filtered.sort((a, b) => a.price - b.price);
  else if (sort === "Price: high to low") filtered.sort((a, b) => b.price - a.price);
  else if (sort === "Best rated") filtered.sort((a, b) => b.rating - a.rating);

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <TrendingUp size={28} className="text-primary" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Trending Now</h1>
            <p className="text-muted-foreground text-sm mt-0.5">{filtered.length} handmade items</p>
          </div>
        </div>

        {/* Category pills */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${cat === c ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* Toolbar */}
        <div className="flex items-center justify-between gap-4 mb-6">
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-2 px-4 py-2.5 border border-border rounded-xl text-sm font-medium hover:bg-secondary transition-colors"
          >
            <SlidersHorizontal size={16} /> Filters
          </button>
          <div className="flex items-center gap-3 ml-auto">
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="text-sm border border-border rounded-xl px-3 py-2.5 bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              {SORTS.map((s) => <option key={s}>{s}</option>)}
            </select>
            <div className="flex gap-1 border border-border rounded-xl p-1">
              <button onClick={() => setView("grid")} className={`p-1.5 rounded-lg transition-colors ${view === "grid" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}><Grid3X3 size={15} /></button>
              <button onClick={() => setView("list")} className={`p-1.5 rounded-lg transition-colors ${view === "list" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}><List size={15} /></button>
            </div>
          </div>
        </div>

        {/* Filters panel */}
        {filtersOpen && (
          <div className="mb-6 p-5 bg-secondary rounded-2xl">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Max Price: ${priceMax}</label>
                <input type="range" min={10} max={200} value={priceMax} onChange={(e) => setPriceMax(Number(e.target.value))} className="w-full accent-primary" />
              </div>
              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Free Shipping</label>
                <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                  <input type="checkbox" className="accent-primary" /> Free shipping only
                </label>
              </div>
              <div>
                <label className="text-sm font-semibold text-foreground mb-2 block">Min Rating</label>
                <div className="flex gap-2">
                  {[4, 4.5, 5].map((r) => (
                    <button key={r} className="px-3 py-1.5 text-xs border border-border rounded-lg hover:border-primary hover:text-primary transition-colors">{r}★+</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Grid */}
        <div className={view === "grid" ? "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6" : "flex flex-col gap-4"}>
          {filtered.map((p, i) => (
            view === "grid" ? (
              <ProductCard key={p.id} product={p} rank={i < 3 ? i + 1 : undefined} />
            ) : (
              <div key={p.id} className="flex gap-4 bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all p-3">
                <img src={p.image} alt={p.name} className="w-24 h-24 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-primary font-medium">{p.seller}</p>
                  <h3 className="text-sm font-semibold text-foreground mt-0.5 line-clamp-1">{p.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.description}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-base font-bold text-foreground">${p.price.toFixed(2)}</span>
                    {p.originalPrice && <span className="text-xs text-muted-foreground line-through">${p.originalPrice.toFixed(2)}</span>}
                    <span className="text-xs text-muted-foreground ml-auto">⭐ {p.rating}</span>
                  </div>
                </div>
              </div>
            )
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <p className="text-2xl font-bold text-foreground mb-2">No products found</p>
            <p className="text-muted-foreground">Try adjusting your filters</p>
            <button onClick={() => { setCat("All"); setPriceMax(200); }} className="mt-4 text-primary hover:underline text-sm">Reset filters</button>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Trending;
