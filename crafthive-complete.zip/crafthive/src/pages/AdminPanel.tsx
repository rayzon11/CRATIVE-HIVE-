import { useState } from "react";
import { BarChart2, Users, Store, Package, ShoppingBag, Tag, Zap, Gift, Share2, AlertTriangle, Settings, DollarSign, TrendingUp, Shield, ChevronUp, Eye, Ban, CheckCircle, XCircle, ArrowUpRight } from "lucide-react";
import { products, sellers } from "@/data/products";

const NAV = [
  { key: "dashboard", icon: BarChart2, label: "Dashboard" },
  { key: "users", icon: Users, label: "Users" },
  { key: "sellers", icon: Store, label: "Sellers" },
  { key: "products", icon: Package, label: "Products" },
  { key: "orders", icon: ShoppingBag, label: "Orders" },
  { key: "categories", icon: Tag, label: "Categories" },
  { key: "flash", icon: Zap, label: "Flash Sales" },
  { key: "giftcards", icon: Gift, label: "Gift Cards" },
  { key: "referrals", icon: Share2, label: "Referrals" },
  { key: "reports", icon: TrendingUp, label: "Reports" },
  { key: "settings", icon: Settings, label: "Settings" },
];

const KPI = ({ label, value, sub, icon: Icon, color = "text-primary" }: { label: string; value: string; sub?: string; icon: typeof BarChart2; color?: string }) => (
  <div className="bg-white rounded-2xl shadow-sm p-5">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-xs text-muted-foreground font-medium">{label}</p>
        <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
        {sub && <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1"><ChevronUp size={11} className="text-green-500" />{sub}</p>}
      </div>
      <div className={`w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0`}>
        <Icon size={18} className={color} />
      </div>
    </div>
  </div>
);

const mockUsers = [
  { name: "Sarah M.", email: "sarah@example.com", role: "buyer", joined: "Jan 2024", status: "active", orders: 8 },
  { name: "BohoThreads", email: "boho@example.com", role: "seller", joined: "Mar 2022", status: "active", orders: 890 },
  { name: "Alex K.", email: "alex@example.com", role: "buyer", joined: "Feb 2024", status: "active", orders: 3 },
  { name: "Jane Admin", email: "admin@crafthive.com", role: "admin", joined: "Jan 2022", status: "active", orders: 0 },
  { name: "ClayStudio", email: "clay@example.com", role: "seller", joined: "Jun 2021", status: "active", orders: 1200 },
];

const AdminPanel = () => {
  const [tab, setTab] = useState("dashboard");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top nav */}
      <div className="bg-gray-900 text-white sticky top-0 z-40">
        <div className="container mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-3">
            <Shield size={18} className="text-primary" />
            <span className="font-bold text-sm">CraftHive Admin</span>
          </div>
          <a href="/" className="text-xs text-white/60 hover:text-white flex items-center gap-1">View Site <ArrowUpRight size={11} /></a>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-52 shrink-0 hidden md:block h-[calc(100vh-56px)] sticky top-14 overflow-y-auto bg-gray-900">
          <nav className="p-3 space-y-0.5">
            {NAV.map(({ key, icon: Icon, label }) => (
              <button
                key={key}
                onClick={() => setTab(key)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${tab === key ? "bg-primary text-primary-foreground font-semibold" : "text-white/70 hover:bg-white/10 hover:text-white"}`}
              >
                <Icon size={15} /> {label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile tabs */}
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 z-40 flex md:hidden overflow-x-auto">
          {NAV.slice(0, 6).map(({ key, icon: Icon, label }) => (
            <button key={key} onClick={() => setTab(key)} className={`flex-1 flex flex-col items-center py-2 gap-0.5 text-[9px] shrink-0 min-w-[60px] ${tab === key ? "text-primary" : "text-white/50"}`}>
              <Icon size={16} /> {label}
            </button>
          ))}
        </div>

        {/* Main */}
        <main className="flex-1 p-4 md:p-6 pb-24 md:pb-6">
          {/* DASHBOARD */}
          {tab === "dashboard" && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-foreground">Dashboard</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <KPI label="Total Revenue" value="$84,210" sub="12% this month" icon={DollarSign} />
                <KPI label="Commission" value="$4,211" sub="5% this month" icon={TrendingUp} />
                <KPI label="Active Listings" value="12,480" icon={Package} />
                <KPI label="Total Users" value="8,341" sub="234 this week" icon={Users} />
                <KPI label="Active Sellers" value="1,209" icon={Store} />
                <KPI label="Orders Today" value="84" sub="↑ 18 vs yesterday" icon={ShoppingBag} />
                <KPI label="Flagged Content" value="3" icon={AlertTriangle} color="text-red-500" />
                <KPI label="Ad Revenue" value="$1,290" sub="this month" icon={Zap} />
              </div>

              {/* Revenue chart */}
              <div className="bg-white rounded-2xl shadow-sm p-5">
                <h3 className="font-bold text-foreground mb-4">Platform Revenue — Last 30 Days</h3>
                <div className="flex items-end gap-1 h-36">
                  {Array.from({ length: 30 }, (_, i) => Math.floor(Math.random() * 4000) + 1000).map((h, i) => (
                    <div key={i} className="flex-1 bg-primary/20 rounded-t-sm hover:bg-primary/40 transition-colors" style={{ height: `${(h / 5000) * 100}%` }} />
                  ))}
                </div>
              </div>

              {/* Alerts */}
              <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                <h3 className="font-semibold text-red-800 flex items-center gap-2 mb-3"><AlertTriangle size={15} /> Flagged Content — Needs Review</h3>
                <div className="space-y-2">
                  {[{ type: "Product", name: "Suspicious listing #4892", time: "2 hours ago" }, { type: "Review", name: "Abusive review on Ceramic Mug", time: "5 hours ago" }].map((a, i) => (
                    <div key={i} className="flex items-center gap-3 bg-white rounded-xl p-3">
                      <span className="text-xs font-semibold text-red-600 bg-red-100 px-2 py-0.5 rounded-full">{a.type}</span>
                      <span className="text-sm text-foreground flex-1">{a.name}</span>
                      <span className="text-xs text-muted-foreground">{a.time}</span>
                      <button className="px-3 py-1 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">Review</button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent orders */}
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="px-5 py-4 border-b border-border"><h3 className="font-bold text-foreground">Recent Orders (All Sellers)</h3></div>
                <table className="w-full text-sm">
                  <thead className="bg-secondary/40"><tr>{["Order", "Buyer", "Seller", "Total", "Status"].map((h) => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>)}</tr></thead>
                  <tbody className="divide-y divide-border">
                    {[["CH-1042", "Sarah M.", "BohoThreads", "$82.00", "delivered"], ["CH-1041", "James K.", "ClayStudio", "$65.00", "shipped"], ["CH-1040", "Emma L.", "SilverPetal", "$42.00", "processing"], ["CH-1039", "Alex P.", "WickCraft", "$34.00", "pending"]].map(([id, buyer, seller, total, status]) => (
                      <tr key={id} className="hover:bg-secondary/20">
                        <td className="px-4 py-3 font-mono text-xs text-foreground">{id}</td>
                        <td className="px-4 py-3 text-muted-foreground">{buyer}</td>
                        <td className="px-4 py-3 text-primary">{seller}</td>
                        <td className="px-4 py-3 font-semibold text-foreground">{total}</td>
                        <td className="px-4 py-3"><span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${status === "delivered" ? "bg-green-100 text-green-700" : status === "shipped" ? "bg-blue-100 text-blue-700" : status === "processing" ? "bg-amber-100 text-amber-700" : "bg-secondary text-muted-foreground"}`}>{status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* USERS */}
          {tab === "users" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">User Management</h2>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-border flex gap-2 flex-wrap">
                  <input placeholder="Search users…" className="flex-1 min-w-[180px] px-3 py-2 text-sm border border-border rounded-xl focus:outline-none" />
                  <select className="px-3 py-2 text-sm border border-border rounded-xl focus:outline-none bg-background text-foreground">
                    <option>All Roles</option><option>Buyer</option><option>Seller</option><option>Admin</option>
                  </select>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/40"><tr>{["User", "Role", "Joined", "Activity", "Status", "Actions"].map((h) => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>)}</tr></thead>
                    <tbody className="divide-y divide-border">
                      {mockUsers.map((user) => (
                        <tr key={user.email} className="hover:bg-secondary/20">
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-foreground">{user.name}</p>
                              <p className="text-xs text-muted-foreground">{user.email}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3"><span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full capitalize ${user.role === "admin" ? "bg-purple-100 text-purple-700" : user.role === "seller" ? "bg-blue-100 text-blue-700" : "bg-secondary text-muted-foreground"}`}>{user.role}</span></td>
                          <td className="px-4 py-3 text-muted-foreground text-xs">{user.joined}</td>
                          <td className="px-4 py-3 text-muted-foreground text-xs">{user.orders} {user.role === "seller" ? "sales" : "orders"}</td>
                          <td className="px-4 py-3"><span className="text-xs font-semibold bg-green-100 text-green-700 px-2.5 py-0.5 rounded-full">{user.status}</span></td>
                          <td className="px-4 py-3">
                            <div className="flex gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors" title="View"><Eye size={13} /></button>
                              <button className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors" title="Suspend"><Ban size={13} /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SELLERS */}
          {tab === "sellers" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Seller Management</h2>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/40"><tr>{["Shop", "Plan", "Revenue", "Products", "Rating", "Status", "Actions"].map((h) => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>)}</tr></thead>
                    <tbody className="divide-y divide-border">
                      {sellers.map((s) => (
                        <tr key={s.id} className="hover:bg-secondary/20">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <img src={s.avatar} alt={s.name} className="w-9 h-9 rounded-lg object-cover" />
                              <div>
                                <p className="font-medium text-foreground">{s.name}</p>
                                <p className="text-xs text-muted-foreground">{s.location}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3"><span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full uppercase ${s.plan === "pro" ? "bg-primary text-primary-foreground" : s.plan === "growth" ? "bg-blue-100 text-blue-700" : "bg-secondary text-muted-foreground"}`}>{s.plan}</span></td>
                          <td className="px-4 py-3 font-semibold text-foreground">{s.sales}</td>
                          <td className="px-4 py-3 text-muted-foreground">{products.filter((p) => p.sellerId === s.id).length}</td>
                          <td className="px-4 py-3"><span className="text-amber-600 font-semibold">★ {s.rating}</span></td>
                          <td className="px-4 py-3"><span className="text-xs font-semibold bg-green-100 text-green-700 px-2.5 py-0.5 rounded-full">Active</span></td>
                          <td className="px-4 py-3">
                            <div className="flex gap-1">
                              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground"><Eye size={13} /></button>
                              <button className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive"><Ban size={13} /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS */}
          {tab === "products" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Product Management</h2>
              <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
                <div className="p-4 border-b border-border flex gap-2">
                  <input placeholder="Search products…" className="flex-1 px-3 py-2 text-sm border border-border rounded-xl focus:outline-none" />
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-secondary/40"><tr>{["Product", "Seller", "Price", "Stock", "Status", "Actions"].map((h) => <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">{h}</th>)}</tr></thead>
                    <tbody className="divide-y divide-border">
                      {products.map((p) => (
                        <tr key={p.id} className="hover:bg-secondary/20">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <img src={p.image} alt={p.name} className="w-9 h-9 rounded-lg object-cover" />
                              <span className="font-medium text-foreground text-xs max-w-[140px] line-clamp-1">{p.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-primary text-xs">{p.seller}</td>
                          <td className="px-4 py-3 font-semibold text-foreground">${p.price.toFixed(2)}</td>
                          <td className="px-4 py-3 text-muted-foreground">{p.stock ?? 0}</td>
                          <td className="px-4 py-3"><span className="text-xs font-semibold bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Active</span></td>
                          <td className="px-4 py-3">
                            <div className="flex gap-1">
                              <button className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground"><Eye size={13} /></button>
                              <button className="p-1 rounded hover:bg-green-50 text-muted-foreground hover:text-green-600" title="Feature"><CheckCircle size={13} /></button>
                              <button className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"><XCircle size={13} /></button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {tab === "settings" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Platform Settings</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
                  <h3 className="font-bold text-foreground">Commission Rates</h3>
                  {[["Free Plan", "8"], ["Growth Plan", "5"], ["Pro Plan", "3"]].map(([label, val]) => (
                    <div key={label}>
                      <label className="text-xs font-medium text-muted-foreground">{label} (%)</label>
                      <input type="number" defaultValue={val} className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none" />
                    </div>
                  ))}
                  <button className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Save</button>
                </div>
                <div className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
                  <h3 className="font-bold text-foreground">Referral Rewards</h3>
                  {[["Buyer referral credit ($)", "2"], ["Seller referral credit ($)", "5"]].map(([label, val]) => (
                    <div key={label}>
                      <label className="text-xs font-medium text-muted-foreground">{label}</label>
                      <input type="number" defaultValue={val} className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none" />
                    </div>
                  ))}
                  <button className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Save</button>
                </div>
                <div className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
                  <h3 className="font-bold text-foreground">Platform Controls</h3>
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <p className="text-sm font-medium text-foreground">Maintenance Mode</p>
                      <p className="text-xs text-muted-foreground">Shows "We'll be right back" page</p>
                    </div>
                    <div className="w-10 h-6 bg-secondary rounded-full relative"><div className="w-4 h-4 bg-white rounded-full absolute top-1 left-1 shadow-sm" /></div>
                  </label>
                  <label className="flex items-center justify-between cursor-pointer">
                    <div>
                      <p className="text-sm font-medium text-foreground">Sponsored Ads</p>
                      <p className="text-xs text-muted-foreground">Enable/disable ad slots</p>
                    </div>
                    <div className="w-10 h-6 bg-primary rounded-full relative"><div className="w-4 h-4 bg-white rounded-full absolute top-1 right-1 shadow-sm" /></div>
                  </label>
                </div>
                <div className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
                  <h3 className="font-bold text-foreground">Site Settings</h3>
                  <div><label className="text-xs font-medium text-muted-foreground">Site Name</label><input defaultValue="CraftHive" className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none" /></div>
                  <div><label className="text-xs font-medium text-muted-foreground">Max Sponsored Slots Per Page</label><input type="number" defaultValue={3} className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none" /></div>
                  <div><label className="text-xs font-medium text-muted-foreground">Min Payout Threshold ($)</label><input type="number" defaultValue={25} className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl focus:outline-none" /></div>
                  <button className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Save</button>
                </div>
              </div>
            </div>
          )}

          {/* REPORTS */}
          {tab === "reports" && (
            <div>
              <h2 className="text-xl font-bold text-foreground mb-5">Reports & Analytics</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="bg-white rounded-2xl shadow-sm p-5">
                  <h3 className="font-bold text-foreground mb-4">Top Sellers by Revenue</h3>
                  {sellers.map((s, i) => (
                    <div key={s.id} className="flex items-center gap-3 mb-3">
                      <span className="text-xs font-bold text-muted-foreground w-4">#{i + 1}</span>
                      <img src={s.avatar} alt={s.name} className="w-7 h-7 rounded-lg object-cover" />
                      <span className="text-sm text-foreground flex-1">{s.name}</span>
                      <span className="text-sm font-bold text-foreground">{s.sales}</span>
                    </div>
                  ))}
                </div>
                <div className="bg-white rounded-2xl shadow-sm p-5">
                  <h3 className="font-bold text-foreground mb-4">Top Products by Sales</h3>
                  {products.sort((a, b) => (b.soldCount ?? 0) - (a.soldCount ?? 0)).slice(0, 5).map((p, i) => (
                    <div key={p.id} className="flex items-center gap-3 mb-3">
                      <span className="text-xs font-bold text-muted-foreground w-4">#{i + 1}</span>
                      <img src={p.image} alt={p.name} className="w-7 h-7 rounded-lg object-cover" />
                      <span className="text-xs text-foreground flex-1 line-clamp-1">{p.name}</span>
                      <span className="text-xs font-bold text-foreground">{p.soldCount} sold</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Other tabs placeholder */}
          {["orders", "categories", "flash", "giftcards", "referrals"].includes(tab) && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                {(() => { const n = NAV.find((n) => n.key === tab); const Icon = n?.icon || Settings; return <Icon size={28} className="text-primary" />; })()}
              </div>
              <p className="text-xl font-bold text-foreground mb-2 capitalize">{NAV.find((n) => n.key === tab)?.label}</p>
              <p className="text-muted-foreground text-sm">This admin section is ready for Supabase integration</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
