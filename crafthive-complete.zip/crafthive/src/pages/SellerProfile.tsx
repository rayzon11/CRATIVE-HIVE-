import { useParams, Link } from "react-router-dom";
import PageLayout from "@/components/PageLayout";
import ProductCard from "@/components/ProductCard";
import { sellers, products } from "@/data/products";
import { Star, MapPin, Calendar, ShoppingBag, Share2, Heart, BadgeCheck, MessageCircle } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

const SellerProfile = () => {
  const { id } = useParams();
  const seller = sellers.find((s) => s.id === id);
  const shopProducts = products.filter((p) => p.sellerId === id);

  if (!seller) {
    return (
      <PageLayout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold">Seller not found</h1>
          <Link to="/sellers" className="text-primary hover:underline mt-4 inline-block">Browse sellers</Link>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout>
      {/* Banner */}
      <div className="relative h-48 md:h-64 bg-secondary overflow-hidden">
        <img src={seller.banner} alt={seller.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background/40 to-transparent" />
      </div>

      <div className="container mx-auto px-4">
        {/* Shop header */}
        <div className="relative -mt-12 mb-6 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div className="flex items-end gap-4">
            <img src={seller.avatar} alt={seller.name} className="w-24 h-24 rounded-2xl border-4 border-background object-cover shadow-lg" />
            <div className="pb-1">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-foreground">{seller.name}</h1>
                {seller.plan !== "free" && <BadgeCheck size={20} className="text-primary" />}
                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${seller.plan === "pro" ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"}`}>
                  {seller.plan.toUpperCase()}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">{seller.specialty}</p>
            </div>
          </div>
          <div className="flex gap-2 pb-1">
            <Button variant="outline" size="sm" className="gap-1.5 rounded-xl"><Heart size={14} /> Follow</Button>
            <Button variant="outline" size="sm" className="gap-1.5 rounded-xl"><Share2 size={14} /> Share</Button>
            <Button size="sm" className="gap-1.5 rounded-xl"><MessageCircle size={14} /> Message</Button>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex flex-wrap gap-6 mb-8 pb-8 border-b border-border">
          {[
            { icon: Star, value: seller.rating, label: "Rating" },
            { icon: ShoppingBag, value: seller.sales, label: "Sales" },
            { icon: MapPin, value: seller.location, label: "Location" },
            { icon: Calendar, value: `Since ${seller.joined}`, label: "Member" },
          ].map(({ icon: Icon, value, label }) => (
            <div key={label} className="flex items-center gap-2">
              <Icon size={15} className="text-primary" />
              <div>
                <p className="text-sm font-bold text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="products">
          <TabsList className="bg-secondary h-auto p-1 rounded-xl mb-8">
            <TabsTrigger value="products" className="rounded-lg text-sm px-5 py-2">Products ({shopProducts.length})</TabsTrigger>
            <TabsTrigger value="about" className="rounded-lg text-sm px-5 py-2">About</TabsTrigger>
            <TabsTrigger value="reviews" className="rounded-lg text-sm px-5 py-2">Reviews</TabsTrigger>
          </TabsList>

          <TabsContent value="products">
            {shopProducts.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
                {shopProducts.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-12">No products listed yet.</p>
            )}
          </TabsContent>

          <TabsContent value="about">
            <div className="max-w-2xl space-y-6">
              <div>
                <h3 className="font-semibold text-foreground mb-2">About {seller.name}</h3>
                <p className="text-muted-foreground leading-relaxed">{seller.bio}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: "Specialty", value: seller.specialty },
                  { label: "Location", value: seller.location },
                  { label: "Response time", value: seller.responseTime },
                  { label: "Member since", value: seller.joined },
                ].map(({ label, value }) => (
                  <div key={label} className="p-4 bg-secondary rounded-xl">
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className="text-sm font-semibold text-foreground mt-0.5">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews">
            <div className="max-w-2xl space-y-4">
              {[4.9, 5.0, 4.8].map((r, i) => (
                <div key={i} className="border-b border-border pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-0.5">{[...Array(5)].map((_, j) => <Star key={j} size={12} className="fill-amber-400 text-amber-400" />)}</div>
                    <span className="text-xs text-muted-foreground">Verified buyer · {["March 2024", "February 2024", "January 2024"][i]}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{"Amazing craftsmanship! Fast shipping and beautifully packaged. Would highly recommend.".repeat(1)}</p>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PageLayout>
  );
};

export default SellerProfile;
