import PageLayout from "@/components/PageLayout";
import { categories } from "@/data/products";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const Categories = () => (
  <PageLayout>
    <div className="container mx-auto px-4 py-8 md:py-12">
      <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">All Categories</h1>
      <p className="text-muted-foreground mb-10">Explore our full range of handmade categories</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {categories.map((cat) => (
          <Link key={cat.slug} to={`/category/${cat.slug}`} className="group relative overflow-hidden rounded-2xl aspect-square bg-secondary hover:shadow-lg transition-all duration-300">
            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-sm font-bold text-primary-foreground">{cat.name}</h3>
              <p className="text-xs text-primary-foreground/70 mt-0.5 flex items-center gap-1">{cat.count} <ArrowRight size={10} /></p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  </PageLayout>
);

export default Categories;
