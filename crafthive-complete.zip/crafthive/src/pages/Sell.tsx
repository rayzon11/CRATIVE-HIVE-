import PageLayout from "@/components/PageLayout";
import { Link } from "react-router-dom";
import { ArrowRight, DollarSign, Package, TrendingUp, Shield } from "lucide-react";

const Sell = () => (
  <PageLayout>
    {/* Hero */}
    <div className="relative bg-primary overflow-hidden py-20">
      <div className="absolute inset-0 opacity-10">
        <img src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&h=600&fit=crop" alt="" className="w-full h-full object-cover" />
      </div>
      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Turn your craft into income</h1>
        <p className="text-primary-foreground/80 max-w-xl mx-auto text-lg mb-8">Join 8,000+ artisans selling on CraftHive. Start free, grow with us.</p>
        <Link to="/login" className="inline-flex items-center gap-2 bg-primary-foreground text-primary px-8 py-4 rounded-full font-bold hover:bg-primary-foreground/90 transition-colors">Open your shop <ArrowRight size={16} /></Link>
      </div>
    </div>

    <div className="container mx-auto px-4 py-16">
      {/* Plans */}
      <h2 className="text-3xl font-bold text-foreground text-center mb-10">Choose your plan</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-16">
        {[
          { name: "Free", price: "$0", commission: "8%", listings: "10 listings", features: ["Basic shop page", "Buyer messaging", "Order management"], highlight: false },
          { name: "Growth", price: "$9.99/mo", commission: "5%", listings: "100 listings", features: ["Verified badge", "Priority ranking", "Coupons", "Analytics PDF"], highlight: false },
          { name: "Pro", price: "$29.99/mo", commission: "3%", listings: "Unlimited", features: ["Homepage feature slot", "Custom shop URL", "CSV import/export", "Flash Sale access", "Priority support"], highlight: true },
        ].map((plan) => (
          <div key={plan.name} className={`rounded-2xl p-6 border-2 ${plan.highlight ? "border-primary bg-primary/5 shadow-lg" : "border-border bg-white shadow-sm"}`}>
            {plan.highlight && <div className="text-center mb-3"><span className="text-xs bg-primary text-primary-foreground px-3 py-1 rounded-full font-semibold">Most Popular</span></div>}
            <h3 className="text-xl font-bold text-foreground text-center">{plan.name}</h3>
            <p className="text-3xl font-bold text-center text-foreground mt-2">{plan.price}</p>
            <p className="text-center text-sm text-muted-foreground mt-1">{plan.commission} commission · {plan.listings}</p>
            <ul className="mt-5 space-y-2">
              {plan.features.map((f) => <li key={f} className="text-sm text-muted-foreground flex items-center gap-2"><span className="text-primary font-bold">✓</span>{f}</li>)}
            </ul>
            <Link to="/login" className={`block mt-6 text-center py-3 rounded-xl text-sm font-bold transition-colors ${plan.highlight ? "bg-primary text-primary-foreground hover:bg-primary/90" : "border border-primary text-primary hover:bg-primary/5"}`}>Get Started</Link>
          </div>
        ))}
      </div>

      {/* Benefits */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
        {[
          { icon: DollarSign, title: "Get paid fast", desc: "Payouts via Stripe Connect within 2 business days" },
          { icon: Package, title: "Easy listing", desc: "Upload products in minutes with our intuitive dashboard" },
          { icon: TrendingUp, title: "Grow your sales", desc: "Sponsored listings and flash sales to boost visibility" },
          { icon: Shield, title: "We've got your back", desc: "Seller protection on every transaction" },
        ].map(({ icon: Icon, title, desc }) => (
          <div key={title}>
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3"><Icon size={22} className="text-primary" /></div>
            <h3 className="font-bold text-foreground text-sm">{title}</h3>
            <p className="text-xs text-muted-foreground mt-1">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  </PageLayout>
);

export default Sell;
