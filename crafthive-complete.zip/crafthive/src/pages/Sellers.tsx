import PageLayout from "@/components/PageLayout";
import { sellers } from "@/data/products";
import { Link } from "react-router-dom";
import { Star, BadgeCheck, Search } from "lucide-react";
import { useState } from "react";

const Sellers = () => {
  const [query, setQuery] = useState("");
  const filtered = sellers.filter((s) =>
    s.name.toLowerCase().includes(query.toLowerCase()) ||
    s.specialty.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground">Meet Our Makers</h1>
          <p className="text-muted-foreground mt-3 max-w-lg mx-auto">Discover talented artisans from around the world, each with their own unique craft and story.</p>
          <div className="relative max-w-md mx-auto mt-6">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search sellers by name or specialty…" className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20" />
          </div>
        </div>

        {/* Sellers grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
          {filtered.map((seller) => (
            <Link key={seller.id} to={`/seller/${seller.id}`} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300">
              <div className="relative h-32 overflow-hidden">
                <img src={seller.banner} alt={seller.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
              </div>
              <div className="px-5 pb-5 -mt-7 relative">
                <div className="flex items-end justify-between">
                  <img src={seller.avatar} alt={seller.name} className="w-14 h-14 rounded-xl border-3 border-white object-cover shadow-sm" />
                  <div className="flex items-center gap-1 bg-amber-50 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full border border-amber-200">
                    <Star size={10} className="fill-amber-400 text-amber-400" /> {seller.rating}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 mt-3">
                  <h3 className="font-bold text-foreground">{seller.name}</h3>
                  {seller.plan !== "free" && <BadgeCheck size={15} className="text-primary" />}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{seller.specialty} · {seller.location}</p>
                <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{seller.bio}</p>
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                  <span className="text-xs text-muted-foreground">{seller.sales} sales</span>
                  <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${seller.plan === "pro" ? "bg-primary/10 text-primary" : seller.plan === "growth" ? "bg-blue-50 text-blue-600" : "bg-secondary text-muted-foreground"}`}>
                    {seller.plan.toUpperCase()}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <p className="text-xl font-bold text-foreground">No sellers found</p>
            <button onClick={() => setQuery("")} className="text-primary hover:underline mt-2 text-sm">Clear search</button>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Sellers;
