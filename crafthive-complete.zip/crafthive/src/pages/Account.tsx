import PageLayout from "@/components/PageLayout";
import { useState } from "react";
import { Package, Heart, MessageCircle, Star, User, Gift, Eye, Settings, LogOut, ChevronRight, Truck, CheckCircle, Clock, XCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { products } from "@/data/products";

const NAV = [
  { key: "profile", icon: User, label: "Profile" },
  { key: "orders", icon: Package, label: "Orders" },
  { key: "wishlists", icon: Heart, label: "Wishlists" },
  { key: "reviews", icon: Star, label: "Reviews" },
  { key: "messages", icon: MessageCircle, label: "Messages" },
  { key: "referrals", icon: Gift, label: "Referrals" },
  { key: "recent", icon: Eye, label: "Recently Viewed" },
];

const mockOrders = [
  { id: "CH-1042", date: "Apr 1, 2024", total: 82.00, status: "delivered", items: [products[0], products[2]] },
  { id: "CH-0991", date: "Mar 15, 2024", total: 58.00, status: "shipped", items: [products[3]] },
  { id: "CH-0876", date: "Feb 28, 2024", total: 145.00, status: "processing", items: [products[14]] },
  { id: "CH-0743", date: "Feb 2, 2024", total: 36.00, status: "cancelled", items: [products[7]] },
];

const statusBadge = (status: string) => {
  const styles: Record<string, string> = {
    delivered: "bg-green-100 text-green-700",
    shipped: "bg-blue-100 text-blue-700",
    processing: "bg-amber-100 text-amber-700",
    cancelled: "bg-red-100 text-red-700",
    pending: "bg-secondary text-muted-foreground",
  };
  const icons: Record<string, typeof CheckCircle> = { delivered: CheckCircle, shipped: Truck, processing: Clock, cancelled: XCircle, pending: Clock };
  const Icon = icons[status] || Clock;
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${styles[status] || "bg-secondary text-foreground"}`}>
      <Icon size={11} /> {status}
    </span>
  );
};

const Account = () => {
  const [tab, setTab] = useState("orders");

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <aside className="md:w-56 shrink-0">
            <div className="bg-white rounded-2xl shadow-sm p-4 mb-4">
              <div className="flex items-center gap-3 pb-4 border-b border-border mb-4">
                <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                  <User size={20} className="text-primary" />
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">Jane Doe</p>
                  <p className="text-xs text-muted-foreground">Buyer · $5 credits</p>
                </div>
              </div>
              <nav className="space-y-0.5">
                {NAV.map(({ key, icon: Icon, label }) => (
                  <button
                    key={key}
                    onClick={() => setTab(key)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm transition-colors ${tab === key ? "bg-primary text-primary-foreground font-semibold" : "text-foreground hover:bg-secondary"}`}
                  >
                    <Icon size={16} /> {label}
                  </button>
                ))}
                <hr className="my-2 border-border" />
                <Link to="/seller" className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-foreground hover:bg-secondary transition-colors">
                  <Settings size={16} /> Seller Dashboard
                </Link>
                <Link to="/login" className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm text-destructive hover:bg-destructive/10 transition-colors">
                  <LogOut size={16} /> Sign Out
                </Link>
              </nav>
            </div>
          </aside>

          {/* Main content */}
          <main className="flex-1 min-w-0">
            {/* ORDERS */}
            {tab === "orders" && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-5">My Orders</h2>
                <div className="space-y-4">
                  {mockOrders.map((order) => (
                    <div key={order.id} className="bg-white rounded-2xl shadow-sm overflow-hidden">
                      <div className="flex items-center justify-between px-5 py-3 bg-secondary/40 border-b border-border">
                        <div className="flex items-center gap-4">
                          <span className="text-sm font-bold text-foreground">{order.id}</span>
                          <span className="text-xs text-muted-foreground">{order.date}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          {statusBadge(order.status)}
                          <span className="text-sm font-bold text-foreground">${order.total.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="p-5">
                        <div className="flex gap-3 flex-wrap">
                          {order.items.map((item) => (
                            <div key={item.id} className="flex items-center gap-2">
                              <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                              <div>
                                <p className="text-xs font-medium text-foreground line-clamp-1 max-w-[150px]">{item.name}</p>
                                <p className="text-xs text-muted-foreground">${item.price.toFixed(2)}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="flex gap-2 mt-4">
                          {order.status === "shipped" && (
                            <button className="px-3 py-1.5 text-xs font-medium bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors flex items-center gap-1.5"><Truck size={11} /> Track Order</button>
                          )}
                          {order.status === "delivered" && (
                            <button className="px-3 py-1.5 text-xs font-medium border border-primary text-primary rounded-lg hover:bg-primary/5 transition-colors flex items-center gap-1.5"><Star size={11} /> Leave Review</button>
                          )}
                          {order.status === "pending" || order.status === "processing" ? (
                            <button className="px-3 py-1.5 text-xs font-medium border border-destructive text-destructive rounded-lg hover:bg-destructive/10 transition-colors flex items-center gap-1.5"><XCircle size={11} /> Cancel Order</button>
                          ) : null}
                          <button className="px-3 py-1.5 text-xs font-medium bg-secondary text-foreground rounded-lg hover:bg-secondary/80 transition-colors">View Details <ChevronRight size={11} className="inline" /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PROFILE */}
            {tab === "profile" && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-5">My Profile</h2>
                <div className="bg-white rounded-2xl shadow-sm p-6 space-y-5">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                      <User size={28} className="text-primary" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">Jane Doe</p>
                      <p className="text-sm text-muted-foreground">jane@example.com</p>
                      <button className="text-xs text-primary hover:underline mt-1">Change avatar</button>
                    </div>
                  </div>
                  {[["Full Name", "Jane Doe"], ["Email", "jane@example.com"], ["Phone", "+1 (555) 000-0000"]].map(([label, val]) => (
                    <div key={label}>
                      <label className="text-xs font-medium text-muted-foreground">{label}</label>
                      <input defaultValue={val} className="mt-1 w-full px-3 py-2.5 text-sm border border-border rounded-xl bg-background focus:outline-none focus:ring-2 focus:ring-primary/20" />
                    </div>
                  ))}
                  <button className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Save Changes</button>
                </div>
              </div>
            )}

            {/* WISHLISTS */}
            {tab === "wishlists" && (
              <div>
                <div className="flex items-center justify-between mb-5">
                  <h2 className="text-xl font-bold text-foreground">Wishlists</h2>
                  <button className="px-3 py-1.5 text-sm font-medium bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors">+ New List</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[{ name: "Gift Ideas", count: 5, public: true }, { name: "My Home", count: 3, public: false }].map((list) => (
                    <div key={list.name} className="bg-white rounded-2xl shadow-sm p-5">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-bold text-foreground">{list.name}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${list.public ? "bg-green-100 text-green-700" : "bg-secondary text-muted-foreground"}`}>{list.public ? "Public" : "Private"}</span>
                      </div>
                      <div className="flex gap-2">
                        {products.slice(0, list.count).map((p) => (
                          <img key={p.id} src={p.image} alt={p.name} className="w-12 h-12 rounded-lg object-cover" />
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground mt-3">{list.count} items</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* REFERRALS */}
            {tab === "referrals" && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-5">Referrals & Credits</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {[{ label: "Credits Balance", value: "$5.00", color: "text-primary" }, { label: "Referrals Sent", value: "3", color: "text-foreground" }, { label: "Credits Earned", value: "$10.00", color: "text-green-600" }].map(({ label, value, color }) => (
                    <div key={label} className="bg-white rounded-2xl shadow-sm p-5 text-center">
                      <p className={`text-2xl font-bold ${color}`}>{value}</p>
                      <p className="text-sm text-muted-foreground mt-1">{label}</p>
                    </div>
                  ))}
                </div>
                <div className="bg-white rounded-2xl shadow-sm p-6">
                  <h3 className="font-bold text-foreground mb-3">Your Referral Link</h3>
                  <div className="flex gap-2">
                    <input readOnly value="https://crafthive.com/ref/janedoe" className="flex-1 px-3 py-2.5 text-sm border border-border rounded-xl bg-secondary text-muted-foreground" />
                    <button className="px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Copy</button>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">Earn $2 when a friend makes their first purchase, $5 when a seller makes their first sale.</p>
                </div>
              </div>
            )}

            {/* RECENT */}
            {tab === "recent" && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-5">Recently Viewed</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {products.slice(0, 8).map((p) => (
                    <Link key={p.id} to={`/product/${p.id}`} className="group">
                      <img src={p.image} alt={p.name} className="w-full aspect-square rounded-xl object-cover group-hover:opacity-90 transition-opacity" />
                      <p className="text-xs font-medium text-foreground mt-2 line-clamp-1">{p.name}</p>
                      <p className="text-xs text-muted-foreground">${p.price.toFixed(2)}</p>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* MESSAGES placeholder */}
            {tab === "messages" && (
              <div className="text-center py-16">
                <MessageCircle size={48} className="text-muted-foreground/30 mx-auto mb-3" />
                <p className="font-bold text-foreground">No messages yet</p>
                <p className="text-sm text-muted-foreground mt-1">Message a seller from any product page</p>
              </div>
            )}

            {/* REVIEWS placeholder */}
            {tab === "reviews" && (
              <div>
                <h2 className="text-xl font-bold text-foreground mb-5">My Reviews</h2>
                <div className="bg-white rounded-2xl shadow-sm p-6 text-center">
                  <Star size={40} className="text-amber-400 mx-auto mb-3" />
                  <p className="font-bold text-foreground mb-1">Leave a review for your recent order</p>
                  <p className="text-sm text-muted-foreground mb-4">Your feedback helps other buyers and supports our artisans.</p>
                  <button onClick={() => setTab("orders")} className="px-5 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">View Orders to Review</button>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </PageLayout>
  );
};

export default Account;
