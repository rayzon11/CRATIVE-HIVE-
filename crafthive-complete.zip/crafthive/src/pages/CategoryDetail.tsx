import { useParams, Link } from "react-router-dom";
import PageLayout from "@/components/PageLayout";
import ProductCard from "@/components/ProductCard";
import { products, categories } from "@/data/products";
import { ChevronRight } from "lucide-react";

const CategoryDetail = () => {
  const { slug } = useParams();
  const category = categories.find((c) => c.slug === slug);
  const categoryProducts = products.filter((p) => p.category === slug);

  return (
    <PageLayout>
      {/* Category banner */}
      {category && (
        <div className="relative h-40 md:h-56 overflow-hidden bg-secondary">
          <img src={category.image} alt={category.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/70 to-foreground/30" />
          <div className="absolute inset-0 flex items-center container mx-auto px-4">
            <div>
              <nav className="flex items-center gap-1.5 text-xs text-primary-foreground/70 mb-2">
                <Link to="/" className="hover:text-primary-foreground">Home</Link>
                <ChevronRight size={12} />
                <Link to="/categories" className="hover:text-primary-foreground">Categories</Link>
                <ChevronRight size={12} />
                <span className="text-primary-foreground">{category.name}</span>
              </nav>
              <h1 className="text-3xl md:text-4xl font-bold text-primary-foreground">{category.name}</h1>
              <p className="text-primary-foreground/80 mt-1 text-sm">{category.count} handmade items</p>
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 py-8 md:py-12">
        {categoryProducts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6">
            {categoryProducts.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-xl font-bold text-foreground mb-2">No products in this category yet</p>
            <Link to="/trending" className="text-primary hover:underline text-sm">Browse all products</Link>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default CategoryDetail;
