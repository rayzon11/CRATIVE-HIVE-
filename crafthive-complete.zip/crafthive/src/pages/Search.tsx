import PageLayout from "@/components/PageLayout";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { useSearchParams } from "react-router-dom";
import { Search as SearchIcon } from "lucide-react";

const Search = () => {
  const [searchParams] = useSearchParams();
  const q = searchParams.get("q") || "";
  const results = products.filter(
    (p) =>
      p.name.toLowerCase().includes(q.toLowerCase()) ||
      p.seller.toLowerCase().includes(q.toLowerCase()) ||
      p.category.toLowerCase().includes(q.toLowerCase()) ||
      p.tags?.some((t) => t.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center gap-3 mb-8">
          <SearchIcon size={22} className="text-primary" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              {q ? <>Results for "<span className="text-primary">{q}</span>"</> : "All Products"}
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">{results.length} items found</p>
          </div>
        </div>

        {results.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6">
            {results.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="text-center py-20">
            <SearchIcon size={52} className="text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-xl font-bold text-foreground mb-2">No results for "{q}"</p>
            <p className="text-muted-foreground text-sm">Try a different search term or browse our categories</p>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Search;
