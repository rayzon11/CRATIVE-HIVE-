import PageLayout from "@/components/PageLayout";
import { Link } from "react-router-dom";
import { Trash2, Plus, Minus, Tag, Gift, CreditCard, ArrowRight, ShoppingBag, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { products } from "@/data/products";

const cartItems = [
  { ...products[0], qty: 1 },
  { ...products[2], qty: 2 },
];

const Cart = () => {
  const [items, setItems] = useState(cartItems.map((i) => ({ ...i })));
  const [coupon, setCoupon] = useState("");
  const [couponApplied, setCouponApplied] = useState(false);
  const [giftCard, setGiftCard] = useState("");
  const [useCredits, setUseCredits] = useState(false);

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const discount = couponApplied ? subtotal * 0.1 : 0;
  const credits = useCredits ? 5 : 0;
  const shipping = subtotal > 50 ? 0 : 5.99;
  const total = subtotal - discount - credits + shipping;

  const updateQty = (id: number, delta: number) =>
    setItems((prev) => prev.map((i) => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i));
  const removeItem = (id: number) => setItems((prev) => prev.filter((i) => i.id !== id));

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <h1 className="text-3xl font-bold text-foreground mb-8 flex items-center gap-3">
          <ShoppingBag size={28} className="text-primary" /> Your Cart
          <span className="text-lg text-muted-foreground font-normal">({items.length} items)</span>
        </h1>

        {items.length === 0 ? (
          <div className="text-center py-24">
            <ShoppingBag size={52} className="text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-xl font-bold text-foreground mb-2">Your cart is empty</p>
            <p className="text-muted-foreground mb-6">Discover handmade treasures to add to your cart</p>
            <Link to="/trending"><Button className="rounded-xl gap-2">Start shopping <ArrowRight size={15} /></Button></Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart items */}
            <div className="lg:col-span-2 space-y-4">
              {/* Group by seller */}
              {["WickCraft", "BohoThreads"].map((sellerName) => {
                const sellerItems = items.filter((i) => i.seller === sellerName);
                if (!sellerItems.length) return null;
                return (
                  <div key={sellerName} className="bg-white rounded-2xl overflow-hidden shadow-sm">
                    <div className="px-5 py-3 bg-secondary/50 border-b border-border flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground">{sellerName}</span>
                      <span className="text-xs text-green-600 flex items-center gap-1"><Truck size={11} /> Free shipping</span>
                    </div>
                    {sellerItems.map((item) => (
                      <div key={item.id} className="flex gap-4 p-5 border-b border-border last:border-0">
                        <Link to={`/product/${item.id}`}>
                          <img src={item.image} alt={item.name} className="w-20 h-20 rounded-xl object-cover shrink-0" />
                        </Link>
                        <div className="flex-1 min-w-0">
                          <Link to={`/product/${item.id}`} className="text-sm font-semibold text-foreground hover:text-primary line-clamp-1">{item.name}</Link>
                          <p className="text-xs text-muted-foreground mt-0.5">{item.seller}</p>
                          <div className="flex items-center gap-3 mt-3">
                            <div className="flex items-center border border-border rounded-lg">
                              <button onClick={() => updateQty(item.id, -1)} className="px-2.5 py-1.5 hover:bg-secondary transition-colors rounded-l-lg"><Minus size={13} /></button>
                              <span className="px-3 text-sm font-medium">{item.qty}</span>
                              <button onClick={() => updateQty(item.id, 1)} className="px-2.5 py-1.5 hover:bg-secondary transition-colors rounded-r-lg"><Plus size={13} /></button>
                            </div>
                            <span className="text-sm font-bold text-foreground">${(item.price * item.qty).toFixed(2)}</span>
                            <button onClick={() => removeItem(item.id)} className="ml-auto text-muted-foreground hover:text-destructive transition-colors p-1"><Trash2 size={15} /></button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>

            {/* Order summary */}
            <div className="space-y-4">
              <div className="bg-white rounded-2xl shadow-sm p-5 space-y-4">
                <h2 className="font-bold text-foreground text-lg">Order Summary</h2>

                {/* Coupon */}
                <div>
                  <label className="text-xs font-medium text-foreground mb-1.5 block flex items-center gap-1.5"><Tag size={12} /> Coupon Code</label>
                  <div className="flex gap-2">
                    <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="SAVE10" className="flex-1 px-3 py-2 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
                    <button onClick={() => setCouponApplied(coupon.length > 0)} className="px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors">Apply</button>
                  </div>
                  {couponApplied && <p className="text-xs text-green-600 mt-1">✓ 10% discount applied!</p>}
                </div>

                {/* Gift card */}
                <div>
                  <label className="text-xs font-medium text-foreground mb-1.5 block flex items-center gap-1.5"><Gift size={12} /> Gift Card</label>
                  <div className="flex gap-2">
                    <input value={giftCard} onChange={(e) => setGiftCard(e.target.value)} placeholder="GC-XXXX-XXXX" className="flex-1 px-3 py-2 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
                    <button className="px-3 py-2 bg-secondary text-foreground text-sm font-medium rounded-xl hover:bg-secondary/80 transition-colors">Apply</button>
                  </div>
                </div>

                {/* Credits */}
                <label className="flex items-center gap-3 cursor-pointer p-3 bg-secondary rounded-xl">
                  <input type="checkbox" checked={useCredits} onChange={(e) => setUseCredits(e.target.checked)} className="accent-primary w-4 h-4" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Use platform credits</p>
                    <p className="text-xs text-muted-foreground">$5.00 available</p>
                  </div>
                </label>

                {/* Breakdown */}
                <div className="space-y-2 pt-2 border-t border-border">
                  {[
                    ["Subtotal", `$${subtotal.toFixed(2)}`],
                    ...(couponApplied ? [["Coupon (SAVE10)", `-$${discount.toFixed(2)}`]] : []),
                    ...(useCredits ? [["Credits", `-$${credits.toFixed(2)}`]] : []),
                    ["Shipping", shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`],
                  ].map(([label, value]) => (
                    <div key={label} className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{label}</span>
                      <span className={value.startsWith("-") ? "text-green-600 font-medium" : "text-foreground"}>{value}</span>
                    </div>
                  ))}
                  <div className="flex justify-between font-bold text-foreground text-base pt-2 border-t border-border">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                <Button size="lg" className="w-full rounded-xl gap-2">
                  <CreditCard size={16} /> Proceed to Checkout
                </Button>

                <div className="flex items-center justify-center gap-2 pt-2">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Stripe_Logo%2C_revised_2016.svg/2560px-Stripe_Logo%2C_revised_2016.svg.png" alt="Stripe" className="h-4 opacity-40" />
                  <span className="text-xs text-muted-foreground">Secured by Stripe</span>
                </div>
              </div>

              {/* Buyer protection */}
              <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
                <p className="text-sm font-semibold text-green-800">🛡️ CraftHive Buyer Protection</p>
                <p className="text-xs text-green-700 mt-1">Full refund if item doesn't arrive or isn't as described.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Cart;
