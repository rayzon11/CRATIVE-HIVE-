import { Link } from "react-router-dom";
import PageLayout from "@/components/PageLayout";
import { Home, Search, ArrowLeft } from "lucide-react";

const NotFound = () => (
  <PageLayout>
    <div className="container mx-auto px-4 py-24 text-center">
      <div className="relative inline-block mb-8">
        <div className="text-[120px] md:text-[160px] font-black text-primary/10 leading-none select-none">404</div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-24 h-24 rounded-3xl bg-primary/10 flex items-center justify-center">
            <span className="text-4xl">🧶</span>
          </div>
        </div>
      </div>
      <h1 className="text-3xl font-bold text-foreground mb-3">Oops! This page unraveled</h1>
      <p className="text-muted-foreground mb-8 max-w-md mx-auto">The page you're looking for doesn't exist or may have been moved. Let's get you back to discovering handmade treasures.</p>
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <Link to="/" className="flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-sm hover:bg-primary/90 transition-colors"><Home size={16} /> Back to Homepage</Link>
        <Link to="/trending" className="flex items-center justify-center gap-2 px-6 py-3 border border-border text-foreground rounded-xl font-semibold text-sm hover:bg-secondary transition-colors"><Search size={16} /> Browse Products</Link>
      </div>
    </div>
  </PageLayout>
);

export default NotFound;
