import { Link } from "react-router-dom";
import { Eye, EyeOff, ArrowRight, Github } from "lucide-react";
import { useState } from "react";

const Login = () => {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [showPass, setShowPass] = useState(false);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1529148482759-b35b25c5f217?w=800&h=1200&fit=crop" alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-10">
          <Link to="/" className="flex items-center gap-2 mb-8">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center"><span className="text-primary-foreground text-sm font-black">CH</span></div>
            <span className="text-2xl font-bold text-primary-foreground">Craft<span className="text-primary">Hive</span></span>
          </Link>
          <p className="text-3xl font-bold text-primary-foreground leading-tight">Where handmade meets the world</p>
          <p className="text-primary-foreground/70 mt-3">Join 50,000+ buyers discovering unique creations from 8,000+ artisans.</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <Link to="/" className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center"><span className="text-primary-foreground text-xs font-black">CH</span></div>
            <span className="text-xl font-bold">Craft<span className="text-primary">Hive</span></span>
          </Link>

          <h1 className="text-2xl font-bold text-foreground mb-1">{mode === "login" ? "Welcome back" : "Create your account"}</h1>
          <p className="text-muted-foreground text-sm mb-6">{mode === "login" ? "Sign in to access your account" : "Start buying or selling handmade goods"}</p>

          {/* Google */}
          <button className="w-full flex items-center justify-center gap-3 py-3 border border-border rounded-xl hover:bg-secondary transition-colors text-sm font-medium text-foreground mb-4">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5" />
            Continue with Google
          </button>

          <div className="flex items-center gap-3 mb-4">
            <hr className="flex-1 border-border" />
            <span className="text-xs text-muted-foreground">or</span>
            <hr className="flex-1 border-border" />
          </div>

          <div className="space-y-3">
            {mode === "signup" && (
              <div>
                <label className="text-xs font-medium text-foreground">Full Name</label>
                <input type="text" placeholder="Jane Doe" className="mt-1 w-full px-4 py-3 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
              </div>
            )}
            <div>
              <label className="text-xs font-medium text-foreground">Email</label>
              <input type="email" placeholder="you@example.com" className="mt-1 w-full px-4 py-3 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
            </div>
            <div>
              <label className="text-xs font-medium text-foreground">Password</label>
              <div className="relative mt-1">
                <input type={showPass ? "text" : "password"} placeholder="••••••••" className="w-full px-4 py-3 pr-11 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">{showPass ? <EyeOff size={16} /> : <Eye size={16} />}</button>
              </div>
            </div>
            {mode === "signup" && (
              <div>
                <label className="text-xs font-medium text-foreground">Referral Code <span className="text-muted-foreground">(optional)</span></label>
                <input type="text" placeholder="e.g. JANEDOE" className="mt-1 w-full px-4 py-3 text-sm border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20" />
              </div>
            )}
          </div>

          {mode === "login" && (
            <div className="text-right mt-2">
              <button className="text-xs text-primary hover:underline">Forgot password?</button>
            </div>
          )}

          {mode === "signup" && (
            <div className="flex items-start gap-2 mt-3">
              <input type="radio" name="role" id="buyer" defaultChecked className="mt-0.5 accent-primary" />
              <div className="mr-4">
                <label htmlFor="buyer" className="text-sm font-medium text-foreground cursor-pointer">I'm a Buyer</label>
                <p className="text-xs text-muted-foreground">Discover & shop handmade goods</p>
              </div>
              <input type="radio" name="role" id="seller" className="mt-0.5 accent-primary" />
              <div>
                <label htmlFor="seller" className="text-sm font-medium text-foreground cursor-pointer">I'm a Seller</label>
                <p className="text-xs text-muted-foreground">Open your artisan shop</p>
              </div>
            </div>
          )}

          <Link to="/" className="w-full mt-5 flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3.5 rounded-xl font-semibold text-sm hover:bg-primary/90 transition-colors">
            {mode === "login" ? "Sign In" : "Create Account"} <ArrowRight size={15} />
          </Link>

          <p className="text-center text-sm text-muted-foreground mt-5">
            {mode === "login" ? "Don't have an account?" : "Already have an account?"}{" "}
            <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="text-primary font-medium hover:underline">
              {mode === "login" ? "Sign up" : "Sign in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
