import PageLayout from "@/components/PageLayout";
import { Heart, Users, Globe, Award } from "lucide-react";

const About = () => (
  <PageLayout>
    <div className="relative h-64 overflow-hidden">
      <img src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&h=600&fit=crop" alt="Artisan workspace" className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 to-foreground/40" />
      <div className="absolute inset-0 flex items-center container mx-auto px-4">
        <div>
          <h1 className="text-4xl font-bold text-primary-foreground">About CraftHive</h1>
          <p className="text-primary-foreground/80 mt-2">Where handmade meets the world</p>
        </div>
      </div>
    </div>
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <div className="prose prose-sm text-muted-foreground space-y-6">
        <p className="text-lg text-foreground leading-relaxed">CraftHive is a premium marketplace for handmade and creative goods, built by makers for makers. We believe that every handmade item tells a story — of creativity, skill, and love.</p>
        <p>Our mission is to connect independent artisans with buyers who appreciate the value of handcrafted goods. We're not just a marketplace; we're a community of makers, dreamers, and art lovers.</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 my-10">
          {[{ icon: Users, value: "8k+", label: "Active sellers" }, { icon: Heart, value: "50k+", label: "Happy buyers" }, { icon: Globe, value: "40+", label: "Countries" }, { icon: Award, value: "4.9★", label: "Avg rating" }].map(({ icon: Icon, value, label }) => (
            <div key={label} className="text-center">
              <Icon size={24} className="text-primary mx-auto mb-2" />
              <p className="text-2xl font-bold text-foreground">{value}</p>
              <p className="text-xs text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>
        <h2 className="text-xl font-bold text-foreground">Our Story</h2>
        <p>Founded in 2022, CraftHive was born from a simple frustration: talented artisans deserved a better platform — one that treated them as partners, not just vendors. We built CraftHive to give makers the tools, visibility, and community they need to grow thriving businesses.</p>
        <h2 className="text-xl font-bold text-foreground">Our Values</h2>
        <ul className="space-y-2">
          <li><strong className="text-foreground">Authenticity</strong> — Every item on CraftHive must be handmade or designed by the seller</li>
          <li><strong className="text-foreground">Community</strong> — We invest in our maker community through education, tools, and support</li>
          <li><strong className="text-foreground">Sustainability</strong> — We encourage eco-friendly practices and materials</li>
          <li><strong className="text-foreground">Transparency</strong> — Clear, fair pricing with no hidden fees</li>
        </ul>
      </div>
    </div>
  </PageLayout>
);

export default About;
