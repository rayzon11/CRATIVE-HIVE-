import { useParams, Link } from "react-router-dom";
import PageLayout from "@/components/PageLayout";
import ProductCard from "@/components/ProductCard";
import { products, sellers } from "@/data/products";
import { Heart, Star, ShoppingBag, Truck, Shield, RotateCcw, MapPin, MessageCircle, Share2, Flag, ChevronRight, Zap, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

const mockReviews = [
  { id: 1, author: "Sarah M.", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&h=60&fit=crop&crop=face", rating: 5, date: "March 2024", body: "Absolutely stunning piece! The quality exceeded my expectations — it arrived beautifully wrapped and looks even better in person. Will definitely buy from this seller again.", photos: ["https://images.unsplash.com/photo-1622397815658-6b759c138230?w=200&h=200&fit=crop"], helpful: 24 },
  { id: 2, author: "James K.", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face", rating: 4, date: "February 2024", body: "Great product, ships fast. Minor issue with the packaging but the item itself is perfect. Seller was very responsive.", photos: [], helpful: 11 },
  { id: 3, author: "Emma L.", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=60&h=60&fit=crop&crop=face", rating: 5, date: "January 2024", body: "I've ordered 3 times now and each piece is just as beautiful as the last. The craftsmanship is exceptional.", photos: [], helpful: 19 },
];

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === Number(id));
  const [selectedImage, setSelectedImage] = useState(0);
  const [qty, setQty] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ h: 5, m: 47, s: 23 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { h, m, s } = prev;
        s--; if (s < 0) { s = 59; m--; } if (m < 0) { m = 59; h--; } if (h < 0) return { h: 0, m: 0, s: 0 };
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!product) {
    return (
      <PageLayout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground">Product not found</h1>
          <Link to="/" className="text-primary hover:underline mt-4 inline-block">Back to shop</Link>
        </div>
      </PageLayout>
    );
  }

  const images = product.images || [product.image];
  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
  const seller = sellers.find((s) => s.id === product.sellerId);
  const pad = (n: number) => String(n).padStart(2, "0");
  const discount = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;

  const ratingBreakdown = [
    { stars: 5, pct: 72 }, { stars: 4, pct: 18 }, { stars: 3, pct: 6 }, { stars: 2, pct: 2 }, { stars: 1, pct: 2 },
  ];

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-8">
          <Link to="/" className="hover:text-primary">Home</Link>
          <ChevronRight size={12} />
          <Link to={`/category/${product.category}`} className="hover:text-primary capitalize">{product.category.replace(/-/g, " ")}</Link>
          <ChevronRight size={12} />
          <span className="text-foreground line-clamp-1">{product.name}</span>
        </nav>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-14">
          {/* Image gallery */}
          <div className="space-y-3">
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-secondary group">
              <img src={images[selectedImage]} alt={product.name} className="w-full h-full object-cover" />
              {product.isSponsored && (
                <span className="absolute top-3 left-3 bg-foreground/60 text-primary-foreground text-[10px] font-semibold px-2.5 py-1 rounded-full backdrop-blur-sm">Sponsored</span>
              )}
              {discount > 0 && (
                <span className="absolute top-3 right-3 bg-primary text-primary-foreground text-xs font-bold px-2.5 py-1 rounded-full">-{discount}%</span>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-colors ${i === selectedImage ? "border-primary" : "border-transparent"}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product info */}
          <div>
            {product.isSponsored && (
              <span className="inline-block text-[10px] text-muted-foreground bg-secondary px-2.5 py-0.5 rounded-full mb-2">Sponsored</span>
            )}
            <Link to={`/seller/${product.sellerId}`} className="text-sm text-primary font-medium hover:underline">
              {product.seller}
            </Link>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mt-1.5 leading-tight">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={15} className={i < Math.floor(product.rating) ? "fill-amber-400 text-amber-400" : "text-border fill-border"} />
                ))}
              </div>
              <span className="text-sm font-semibold text-foreground">{product.rating}</span>
              <span className="text-sm text-muted-foreground">({product.reviews.toLocaleString()} reviews)</span>
              <span className="text-sm text-muted-foreground">· {product.soldCount} sold</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mt-5">
              <span className="text-3xl font-bold text-foreground">${product.price.toFixed(2)}</span>
              {product.originalPrice && (
                <span className="text-lg text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
              )}
              {discount > 0 && (
                <Badge className="bg-primary/10 text-primary border-primary/20">Save {discount}%</Badge>
              )}
            </div>

            {/* Flash sale timer */}
            {product.id === 3 && (
              <div className="mt-4 flex items-center gap-3 bg-primary/10 border border-primary/20 rounded-xl px-4 py-3">
                <Zap size={16} className="text-primary shrink-0" />
                <span className="text-sm text-foreground font-medium">Flash Sale ends in</span>
                <div className="flex items-center gap-1 font-mono text-sm font-bold text-primary">
                  <span>{pad(timeLeft.h)}h</span><span>:</span><span>{pad(timeLeft.m)}m</span><span>:</span><span>{pad(timeLeft.s)}s</span>
                </div>
              </div>
            )}

            {/* Stock warning */}
            {product.stock && product.stock < 5 && (
              <p className="mt-3 text-sm font-medium text-amber-600 flex items-center gap-1.5">
                <Package size={14} /> Only {product.stock} left in stock — order soon!
              </p>
            )}

            {/* Quantity + Add to cart */}
            <div className="flex items-center gap-3 mt-6">
              <div className="flex items-center border border-border rounded-xl">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-3.5 py-3 text-foreground hover:bg-secondary transition-colors rounded-l-xl text-sm">−</button>
                <span className="px-4 py-3 text-sm font-medium text-foreground min-w-[3rem] text-center">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="px-3.5 py-3 text-foreground hover:bg-secondary transition-colors rounded-r-xl text-sm">+</button>
              </div>
              <Button
                size="lg"
                className="flex-1 rounded-xl gap-2"
                onClick={() => { setAddedToCart(true); setTimeout(() => setAddedToCart(false), 2000); }}
              >
                <ShoppingBag size={17} />
                {addedToCart ? "Added! ✓" : "Add to Cart"}
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="rounded-xl px-4"
                onClick={() => setWishlisted(!wishlisted)}
              >
                <Heart size={17} className={wishlisted ? "fill-primary text-primary" : ""} />
              </Button>
            </div>

            <Button variant="outline" size="lg" className="w-full mt-3 rounded-xl">
              Buy Now
            </Button>

            {/* Shipping info */}
            <div className="mt-6 p-4 bg-secondary rounded-xl space-y-2.5">
              <div className="flex items-center gap-3 text-sm">
                <Truck size={16} className="text-primary shrink-0" />
                <span className="text-foreground">
                  {product.freeShipping ? <span className="text-green-600 font-medium">Free shipping</span> : "Shipping calculated at checkout"}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Package size={16} className="text-primary shrink-0" />
                <span className="text-muted-foreground">Ready to ship in {product.processingDays}–{(product.processingDays ?? 3) + 2} business days</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <MapPin size={16} className="text-primary shrink-0" />
                <span className="text-muted-foreground">Ships from {seller?.location || "United States"}</span>
              </div>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mt-6">
              {[
                { icon: Shield, label: "Buyer Protection" },
                { icon: RotateCcw, label: "Easy Returns" },
                { icon: Truck, label: "Tracked Shipping" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center text-center gap-1.5 p-3 bg-secondary rounded-xl">
                  <Icon size={18} className="text-primary" />
                  <span className="text-[10px] text-muted-foreground font-medium">{label}</span>
                </div>
              ))}
            </div>

            {/* Seller card */}
            {seller && (
              <div className="mt-6 p-4 border border-border rounded-2xl">
                <div className="flex items-center gap-3">
                  <img src={seller.avatar} alt={seller.name} className="w-12 h-12 rounded-xl object-cover" />
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <Link to={`/seller/${seller.id}`} className="font-bold text-foreground hover:text-primary text-sm">{seller.name}</Link>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Star size={11} className="fill-amber-400 text-amber-400" />
                      <span className="text-xs text-muted-foreground">{seller.rating} · {seller.sales} sales · {seller.responseTime}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Link to={`/seller/${seller.id}`} className="flex-1 text-center text-xs font-medium text-primary border border-primary/30 py-2 rounded-xl hover:bg-primary/5 transition-colors">
                    Visit shop
                  </Link>
                  <button className="flex-1 flex items-center justify-center gap-1.5 text-xs font-medium text-foreground border border-border py-2 rounded-xl hover:bg-secondary transition-colors">
                    <MessageCircle size={13} /> Message seller
                  </button>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-4 mt-4">
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
                <Share2 size={13} /> Share
              </button>
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-destructive transition-colors">
                <Flag size={13} /> Report listing
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-14">
          <Tabs defaultValue="description">
            <TabsList className="bg-secondary h-auto p-1 rounded-xl">
              <TabsTrigger value="description" className="rounded-lg text-sm px-5 py-2.5">Description</TabsTrigger>
              <TabsTrigger value="shipping" className="rounded-lg text-sm px-5 py-2.5">Shipping & Returns</TabsTrigger>
              <TabsTrigger value="reviews" className="rounded-lg text-sm px-5 py-2.5">Reviews ({product.reviews})</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-6 prose prose-sm max-w-none">
              <div className="text-muted-foreground leading-relaxed">
                <p>{product.description}</p>
                <p className="mt-4">Each piece is handcrafted with care and attention to detail. Because these items are made by hand, slight variations in color, texture, or size are natural and add to the unique character of your purchase.</p>
                <div className="mt-6 grid grid-cols-2 gap-4">
                  {product.tags?.map((tag) => (
                    <div key={tag} className="flex items-center gap-2 text-sm">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                      <span className="capitalize">{tag}</span>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="shipping" className="mt-6 space-y-4">
              {[
                { title: "Processing time", body: `This item will be ready to ship in ${product.processingDays}–${(product.processingDays ?? 3) + 2} business days.` },
                { title: "Shipping", body: product.freeShipping ? "Free standard shipping on this item. Express options available at checkout." : "Shipping cost calculated at checkout based on your location." },
                { title: "Returns & exchanges", body: "Returns accepted within 14 days of delivery. Item must be unused and in original packaging. Buyer pays return shipping." },
              ].map(({ title, body }) => (
                <div key={title} className="p-4 bg-secondary rounded-xl">
                  <h4 className="font-semibold text-foreground text-sm">{title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{body}</p>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              {/* Star breakdown */}
              <div className="flex flex-col md:flex-row gap-8 mb-8">
                <div className="text-center">
                  <p className="text-5xl font-bold text-foreground">{product.rating}</p>
                  <div className="flex justify-center mt-2 gap-0.5">
                    {[...Array(5)].map((_, i) => <Star key={i} size={16} className="fill-amber-400 text-amber-400" />)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{product.reviews} reviews</p>
                </div>
                <div className="flex-1 space-y-2">
                  {[5, 4, 3, 2, 1].map((star) => {
                    const pct = star === 5 ? 72 : star === 4 ? 18 : star === 3 ? 6 : star === 2 ? 2 : 2;
                    return (
                      <div key={star} className="flex items-center gap-2 text-xs">
                        <span className="w-4 text-right text-muted-foreground">{star}</span>
                        <Star size={10} className="fill-amber-400 text-amber-400 shrink-0" />
                        <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                          <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="w-6 text-muted-foreground">{pct}%</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Reviews list */}
              <div className="space-y-6">
                {mockReviews.map((review) => (
                  <div key={review.id} className="border-b border-border pb-6 last:border-0">
                    <div className="flex items-start gap-3">
                      <img src={review.avatar} alt={review.author} className="w-9 h-9 rounded-full object-cover" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-foreground">{review.author}</span>
                          <span className="text-xs text-muted-foreground">{review.date}</span>
                        </div>
                        <div className="flex gap-0.5 mt-1">
                          {[...Array(5)].map((_, i) => <Star key={i} size={11} className={i < review.rating ? "fill-amber-400 text-amber-400" : "text-border fill-border"} />)}
                        </div>
                        <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{review.body}</p>
                        {review.photos.length > 0 && (
                          <div className="flex gap-2 mt-3">
                            {review.photos.map((photo, i) => (
                              <img key={i} src={photo} alt="" className="w-16 h-16 rounded-xl object-cover" />
                            ))}
                          </div>
                        )}
                        <button className="text-xs text-muted-foreground mt-3 hover:text-foreground transition-colors">
                          👍 Helpful ({review.helpful})
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-foreground mb-8">You may also like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default ProductDetail;
