import PageLayout from "@/components/PageLayout";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { Heart, Plus, Share2 } from "lucide-react";
import { useState } from "react";

const Wishlist = () => {
  const [activeList, setActiveList] = useState("Gift Ideas");
  const lists = [{ name: "Gift Ideas", items: products.slice(0, 4), public: true }, { name: "My Home", items: products.slice(4, 7), public: false }];
  const currentList = lists.find((l) => l.name === activeList);

  return (
    <PageLayout>
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3"><Heart size={26} className="text-primary fill-primary" /> Wishlists</h1>
          <button className="flex items-center gap-1.5 px-4 py-2.5 bg-primary text-primary-foreground text-sm font-medium rounded-xl hover:bg-primary/90 transition-colors"><Plus size={15} /> New List</button>
        </div>
        <div className="flex gap-2 mb-8">
          {lists.map((l) => (
            <button key={l.name} onClick={() => setActiveList(l.name)} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${activeList === l.name ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"}`}>
              {l.name} ({l.items.length}) {l.public ? "🔗" : "🔒"}
            </button>
          ))}
        </div>
        {currentList && (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${currentList.public ? "bg-green-100 text-green-700" : "bg-secondary text-muted-foreground"}`}>{currentList.public ? "Public" : "Private"}</span>
              {currentList.public && <button className="flex items-center gap-1.5 text-xs text-primary hover:underline"><Share2 size={11} /> Share list</button>}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6">
              {currentList.items.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </PageLayout>
  );
};

export default Wishlist;
