import Navbar from "@/components/Navbar";
import FlashSaleBanner from "@/components/FlashSaleBanner";
import HeroSection from "@/components/HeroSection";
import CategoryGrid from "@/components/CategoryGrid";
import TrendingProducts from "@/components/TrendingProducts";
import FeaturedSellers from "@/components/FeaturedSellers";
import CtaBanner from "@/components/CtaBanner";
import Footer from "@/components/Footer";
import CookieConsent from "@/components/CookieConsent";
import { products } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const NewArrivals = () => {
  const newest = products.slice(12, 20);
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold text-primary uppercase tracking-widest mb-2">Just added</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">New Arrivals</h2>
          </div>
          <Link to="/trending" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6">
          {newest.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </section>
  );
};

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <FlashSaleBanner />
      <Navbar />
      <main>
        <HeroSection />
        <CategoryGrid />
        <TrendingProducts />
        <FeaturedSellers />
        <NewArrivals />
        <CtaBanner />
      </main>
      <Footer />
      <CookieConsent />
    </div>
  );
};

export default Index;
