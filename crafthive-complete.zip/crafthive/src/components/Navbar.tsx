import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, ShoppingBag, Heart, User, Menu, X, Bell, ChevronDown, LogIn, Package, Settings, LayoutDashboard, Store } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [cartCount] = useState(2);
  const [notifCount] = useState(3);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClick = () => setUserMenuOpen(false);
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-18 gap-4">
          {/* Mobile menu toggle */}
          <button className="md:hidden p-2 -ml-2 text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground text-sm font-black">CH</span>
            </div>
            <span className="text-xl md:text-2xl font-bold text-foreground tracking-tight">
              Craft<span className="text-primary">Hive</span>
            </span>
          </Link>

          {/* Desktop search */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-lg relative">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search handmade treasures…"
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-secondary text-foreground placeholder:text-muted-foreground border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 text-sm transition-all"
            />
          </form>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-6 shrink-0">
            <Link to="/categories" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Categories</Link>
            <Link to="/trending" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Trending</Link>
            <Link to="/sellers" className="text-sm font-medium text-foreground hover:text-primary transition-colors">Sellers</Link>
            <Link to="/sell" className="text-sm font-medium text-primary hover:text-primary/80 transition-colors">Start Selling</Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Notifications */}
            <Link to="/account" className="p-2.5 rounded-full hover:bg-secondary transition-colors text-foreground relative hidden sm:flex">
              <Bell size={20} />
              {notifCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-primary-foreground text-[9px] font-bold rounded-full flex items-center justify-center">{notifCount}</span>
              )}
            </Link>
            {/* Wishlist */}
            <Link to="/wishlist" className="p-2.5 rounded-full hover:bg-secondary transition-colors text-foreground hidden sm:flex">
              <Heart size={20} />
            </Link>
            {/* Cart */}
            <Link to="/cart" className="p-2.5 rounded-full hover:bg-secondary transition-colors text-foreground relative">
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-primary-foreground text-[9px] font-bold rounded-full flex items-center justify-center">{cartCount}</span>
              )}
            </Link>
            {/* User menu */}
            <div className="relative hidden md:block" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-full hover:bg-secondary transition-colors text-foreground"
              >
                <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
                  <User size={15} className="text-primary" />
                </div>
                <ChevronDown size={14} className={`transition-transform ${userMenuOpen ? "rotate-180" : ""}`} />
              </button>
              {userMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-52 bg-background border border-border rounded-2xl shadow-lg overflow-hidden z-50 animate-fade-in">
                  <div className="p-3 border-b border-border">
                    <p className="text-xs text-muted-foreground">Signed in as</p>
                    <p className="text-sm font-semibold text-foreground">guest@crafthive.com</p>
                  </div>
                  <div className="p-1.5">
                    <Link to="/account" className="flex items-center gap-2.5 px-3 py-2 text-sm text-foreground hover:bg-secondary rounded-xl transition-colors"><Package size={15} /> My Orders</Link>
                    <Link to="/account" className="flex items-center gap-2.5 px-3 py-2 text-sm text-foreground hover:bg-secondary rounded-xl transition-colors"><LayoutDashboard size={15} /> Buyer Dashboard</Link>
                    <Link to="/seller" className="flex items-center gap-2.5 px-3 py-2 text-sm text-foreground hover:bg-secondary rounded-xl transition-colors"><Store size={15} /> Seller Dashboard</Link>
                    <Link to="/admin" className="flex items-center gap-2.5 px-3 py-2 text-sm text-foreground hover:bg-secondary rounded-xl transition-colors"><Settings size={15} /> Admin Panel</Link>
                    <hr className="my-1.5 border-border" />
                    <Link to="/login" className="flex items-center gap-2.5 px-3 py-2 text-sm text-destructive hover:bg-destructive/10 rounded-xl transition-colors"><LogIn size={15} /> Sign Out</Link>
                  </div>
                </div>
              )}
            </div>
            <Link to="/login" className="md:hidden p-2.5 rounded-full hover:bg-secondary transition-colors text-foreground">
              <User size={20} />
            </Link>
          </div>
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-background animate-fade-in">
          <div className="container mx-auto px-4 py-3">
            <form onSubmit={handleSearch} className="relative mb-3">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search…" className="w-full pl-9 pr-4 py-2.5 rounded-full bg-secondary text-sm border border-border focus:outline-none" />
            </form>
            <nav className="flex flex-col gap-1">
              <Link to="/categories" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Categories</Link>
              <Link to="/trending" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Trending</Link>
              <Link to="/sellers" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Sellers</Link>
              <Link to="/sell" className="px-3 py-2 text-sm font-medium text-primary hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Start Selling</Link>
              <Link to="/account" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>My Account</Link>
              <Link to="/seller" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Seller Dashboard</Link>
              <Link to="/admin" className="px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Admin Panel</Link>
              <Link to="/login" className="px-3 py-2 text-sm font-medium text-primary hover:bg-secondary rounded-xl" onClick={() => setMobileOpen(false)}>Sign In</Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
