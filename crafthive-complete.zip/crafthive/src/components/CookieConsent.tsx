import { useState, useEffect } from "react";
import { Cookie, X, Shield } from "lucide-react";

const CookieConsent = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("crafthive-cookie-consent");
    if (!consent) setTimeout(() => setVisible(true), 2000);
  }, []);

  const accept = () => {
    localStorage.setItem("crafthive-cookie-consent", "all");
    setVisible(false);
  };

  const necessary = () => {
    localStorage.setItem("crafthive-cookie-consent", "necessary");
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-6 md:bottom-6 md:max-w-sm z-[100] animate-fade-in">
      <div className="bg-foreground text-primary-foreground rounded-2xl shadow-2xl p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <Cookie size={18} className="text-primary shrink-0" />
            <p className="font-bold text-sm">We use cookies 🍪</p>
          </div>
          <button onClick={() => setVisible(false)} className="text-primary-foreground/60 hover:text-primary-foreground transition-colors shrink-0">
            <X size={16} />
          </button>
        </div>
        <p className="text-xs text-primary-foreground/70 leading-relaxed mb-4">
          We use cookies to enhance your browsing experience, personalise content and ads, and to analyse our traffic. You can choose to accept all cookies or only those necessary to run the site.
        </p>
        <div className="flex items-center gap-2">
          <button
            onClick={necessary}
            className="flex-1 py-2 text-xs font-medium border border-primary-foreground/20 text-primary-foreground/70 rounded-xl hover:border-primary-foreground/40 transition-colors"
          >
            Necessary only
          </button>
          <button
            onClick={accept}
            className="flex-1 py-2 text-xs font-bold bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5"
          >
            <Shield size={12} /> Accept all
          </button>
        </div>
      </div>
    </div>
  );
};

export default CookieConsent;
