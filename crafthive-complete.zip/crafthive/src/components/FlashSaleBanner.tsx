import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Zap, ArrowRight, X } from "lucide-react";

const FlashSaleBanner = () => {
  // Flash sale ends in 6 hours from now
  const [timeLeft, setTimeLeft] = useState({ h: 5, m: 47, s: 23 });
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { h, m, s } = prev;
        s--;
        if (s < 0) { s = 59; m--; }
        if (m < 0) { m = 59; h--; }
        if (h < 0) return { h: 0, m: 0, s: 0 };
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (dismissed) return null;

  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <div className="bg-primary text-primary-foreground py-3 px-4 relative">
      <div className="container mx-auto flex items-center justify-center gap-3 md:gap-6 text-sm flex-wrap">
        <div className="flex items-center gap-2 font-semibold">
          <Zap size={16} className="fill-current" />
          <span>FLASH SALE — Up to 40% off handmade goods!</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-xs">
          <span className="bg-primary-foreground/20 px-2 py-0.5 rounded font-bold">{pad(timeLeft.h)}</span>
          <span>:</span>
          <span className="bg-primary-foreground/20 px-2 py-0.5 rounded font-bold">{pad(timeLeft.m)}</span>
          <span>:</span>
          <span className="bg-primary-foreground/20 px-2 py-0.5 rounded font-bold">{pad(timeLeft.s)}</span>
        </div>
        <Link to="/trending" className="flex items-center gap-1 text-xs font-semibold underline underline-offset-2 hover:no-underline">
          Shop now <ArrowRight size={12} />
        </Link>
      </div>
      <button onClick={() => setDismissed(true)} className="absolute right-3 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity">
        <X size={16} />
      </button>
    </div>
  );
};

export default FlashSaleBanner;
