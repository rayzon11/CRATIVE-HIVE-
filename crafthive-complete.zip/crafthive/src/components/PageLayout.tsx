import Navbar from "./Navbar";
import Footer from "./Footer";
import FlashSaleBanner from "./FlashSaleBanner";
import { ReactNode } from "react";

const PageLayout = ({ children }: { children: ReactNode }) => (
  <div className="min-h-screen bg-background flex flex-col">
    <FlashSaleBanner />
    <Navbar />
    <main className="flex-1">{children}</main>
    <Footer />
  </div>
);

export default PageLayout;
