import { Search, Sparkles, ArrowRight } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
  };

  const tags = ["Jewelry", "Pottery", "Art Prints", "Candles", "Clothing", "Macramé"];

  return (
    <section className="relative overflow-hidden min-h-[85vh] flex items-center">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&h=1080&fit=crop"
          alt="Artisan workspace"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/85 via-foreground/60 to-foreground/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 via-transparent to-transparent" />
      </div>

      <div className="container mx-auto px-4 relative z-10 py-20">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 backdrop-blur-sm border border-primary/30 text-primary-foreground text-xs font-medium mb-6 animate-fade-in">
            <Sparkles size={12} className="text-primary" />
            Over 50,000 handmade items
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-primary-foreground leading-tight animate-fade-in">
            Handmade with
            <span className="text-primary"> Heart</span>,
            <br />Made for You
          </h1>
          <p className="mt-5 text-base md:text-lg text-primary-foreground/80 leading-relaxed max-w-xl animate-fade-in" style={{ animationDelay: "0.1s" }}>
            Discover unique, handcrafted treasures from artisans around the world. Every purchase supports an independent maker.
          </p>

          {/* Search bar */}
          <form onSubmit={handleSearch} className="mt-8 relative max-w-xl animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <Search size={20} className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for jewelry, art, pottery…"
              className="w-full pl-14 pr-36 py-4 rounded-full bg-background text-foreground placeholder:text-muted-foreground shadow-lg focus:outline-none focus:ring-2 focus:ring-primary/30 text-sm md:text-base transition-all"
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-5 py-2.5 rounded-full font-medium text-sm hover:bg-primary/90 transition-colors flex items-center gap-1.5">
              Search <ArrowRight size={14} />
            </button>
          </form>

          {/* Quick tags */}
          <div className="mt-5 flex flex-wrap gap-2 animate-fade-in" style={{ animationDelay: "0.3s" }}>
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => navigate(`/search?q=${encodeURIComponent(tag)}`)}
                className="px-3.5 py-1.5 rounded-full bg-primary-foreground/10 text-primary-foreground/80 text-xs font-medium backdrop-blur-sm hover:bg-primary-foreground/20 cursor-pointer transition-colors border border-primary-foreground/10"
              >
                {tag}
              </button>
            ))}
          </div>

          {/* Stats */}
          <div className="mt-10 flex items-center gap-8 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            {[
              { value: "50k+", label: "Handmade items" },
              { value: "8k+", label: "Artisan sellers" },
              { value: "4.9★", label: "Average rating" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="text-xl md:text-2xl font-bold text-primary-foreground">{stat.value}</p>
                <p className="text-xs text-primary-foreground/60">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
