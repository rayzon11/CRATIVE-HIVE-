import { products } from "@/data/products";
import ProductCard from "./ProductCard";
import { Link } from "react-router-dom";
import { ArrowRight, TrendingUp } from "lucide-react";

const TrendingProducts = () => {
  const trending = [...products].sort((a, b) => (b.soldCount ?? 0) - (a.soldCount ?? 0)).slice(0, 8);

  return (
    <section className="py-16 md:py-24 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="flex items-end justify-between mb-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp size={16} className="text-primary" />
              <p className="text-xs font-semibold text-primary uppercase tracking-widest">This week</p>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Trending Now</h2>
          </div>
          <Link to="/trending" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
            See all <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-6">
          {trending.map((product, i) => (
            <ProductCard key={product.id} product={product} rank={i < 3 ? i + 1 : undefined} />
          ))}
        </div>

        <div className="text-center mt-8 md:hidden">
          <Link to="/trending" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary">
            See all trending <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default TrendingProducts;
