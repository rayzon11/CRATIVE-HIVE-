import { Link } from "react-router-dom";
import { Instagram, Twitter, Facebook, Youtube, Send } from "lucide-react";
import { useState } from "react";

const Footer = () => {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) { setSubscribed(true); setEmail(""); }
  };

  return (
    <footer className="bg-foreground text-primary-foreground">
      {/* Newsletter strip */}
      <div className="border-b border-primary-foreground/10">
        <div className="container mx-auto px-4 py-10">
          <div className="flex flex-col md:flex-row items-center gap-6 justify-between">
            <div>
              <h3 className="text-lg font-bold">Stay in the loop</h3>
              <p className="text-sm text-primary-foreground/60 mt-1">New arrivals, flash sales, and maker stories — delivered weekly.</p>
            </div>
            {subscribed ? (
              <p className="text-sm text-primary font-medium">🎉 You're subscribed! Thank you.</p>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 w-full md:w-auto">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="flex-1 md:w-64 px-4 py-2.5 rounded-xl bg-primary-foreground/10 border border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/40 text-sm focus:outline-none focus:border-primary"
                />
                <button type="submit" className="px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors flex items-center gap-1.5">
                  Subscribe <Send size={13} />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="container mx-auto px-4 py-14">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground text-xs font-black">CH</span>
              </div>
              <span className="text-lg font-bold">Craft<span className="text-primary">Hive</span></span>
            </div>
            <p className="text-sm text-primary-foreground/60 leading-relaxed">
              Discover unique handmade & creative goods from talented artisans worldwide.
            </p>
            <div className="flex items-center gap-3 mt-5">
              {[Instagram, Twitter, Facebook, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-8 h-8 rounded-lg bg-primary-foreground/10 flex items-center justify-center hover:bg-primary transition-colors text-primary-foreground/70 hover:text-primary-foreground">
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="font-bold mb-4 text-sm">Shop</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/categories" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">All Categories</Link>
              <Link to="/trending" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Trending</Link>
              <Link to="/search?q=new" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">New Arrivals</Link>
              <Link to="/search?q=sale" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">On Sale</Link>
              <Link to="/sellers" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">All Sellers</Link>
            </div>
          </div>

          {/* Sell */}
          <div>
            <h4 className="font-bold mb-4 text-sm">Sell</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/sell" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Start Selling</Link>
              <Link to="/seller" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Seller Dashboard</Link>
              <Link to="/sell" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Fees & Pricing</Link>
              <Link to="/sell" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Seller Handbook</Link>
            </div>
          </div>

          {/* Account */}
          <div>
            <h4 className="font-bold mb-4 text-sm">Account</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/account" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">My Orders</Link>
              <Link to="/account" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Wishlists</Link>
              <Link to="/account" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Messages</Link>
              <Link to="/account" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Referrals</Link>
            </div>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-bold mb-4 text-sm">Company</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/about" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">About Us</Link>
              <Link to="/about" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Contact</Link>
              <Link to="/about" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Privacy Policy</Link>
              <Link to="/about" className="text-sm text-primary-foreground/60 hover:text-primary transition-colors">Terms of Service</Link>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-primary-foreground/40">
            © {new Date().getFullYear()} CraftHive — All rights reserved. Made with ❤️ for artisans worldwide.
          </p>
          <div className="flex items-center gap-4">
            <img src="https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=60&h=30&fit=crop" alt="Stripe" className="h-5 rounded opacity-40" />
            <span className="text-xs text-primary-foreground/30">Secured by Stripe</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
