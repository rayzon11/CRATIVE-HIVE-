import { Heart, Star, Truck, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { Product } from "@/data/products";
import { useState } from "react";

interface ProductCardProps {
  product: Product;
  rank?: number;
}

const ProductCard = ({ product, rank }: ProductCardProps) => {
  const [wishlisted, setWishlisted] = useState(false);
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300">
      {/* Image */}
      <Link to={`/product/${product.id}`} className="block relative aspect-square overflow-hidden bg-secondary">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5">
          {product.isSponsored && (
            <span className="bg-foreground/70 text-primary-foreground text-[9px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-sm">Sponsored</span>
          )}
          {discount > 0 && (
            <span className="bg-primary text-primary-foreground text-[9px] font-bold px-2 py-0.5 rounded-full">-{discount}%</span>
          )}
          {rank && rank <= 3 && (
            <span className="bg-amber-400 text-amber-900 text-[9px] font-bold px-2 py-0.5 rounded-full">#{rank} Trending</span>
          )}
        </div>

        {/* Wishlist */}
        <button
          onClick={(e) => { e.preventDefault(); setWishlisted(!wishlisted); }}
          className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-white/80 backdrop-blur-sm text-foreground hover:text-primary transition-colors shadow-sm"
        >
          <Heart size={14} className={wishlisted ? "fill-primary text-primary" : ""} />
        </button>

        {/* Free shipping badge */}
        {product.freeShipping && (
          <div className="absolute bottom-2.5 left-2.5 flex items-center gap-1 bg-green-500/90 text-white text-[9px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-sm">
            <Truck size={9} /> Free shipping
          </div>
        )}

        {/* Flash sale indicator */}
        {product.id === 3 && (
          <div className="absolute bottom-2.5 right-2.5 flex items-center gap-1 bg-primary/90 text-primary-foreground text-[9px] font-semibold px-2 py-0.5 rounded-full backdrop-blur-sm">
            <Zap size={9} /> Flash Sale
          </div>
        )}
      </Link>

      {/* Info */}
      <Link to={`/product/${product.id}`} className="block p-3 md:p-4">
        <p className="text-[10px] md:text-xs text-primary font-medium truncate">{product.seller}</p>
        <h3 className="text-xs md:text-sm font-semibold text-foreground mt-0.5 line-clamp-2 leading-snug">
          {product.name}
        </h3>
        <div className="flex items-center gap-1 mt-1.5">
          <Star size={11} className="fill-amber-400 text-amber-400" />
          <span className="text-[10px] md:text-xs font-medium text-foreground">{product.rating}</span>
          <span className="text-[10px] md:text-xs text-muted-foreground">({product.reviews})</span>
        </div>
        <div className="flex items-center gap-2 mt-2">
          <p className="text-sm md:text-base font-bold text-foreground">${product.price.toFixed(2)}</p>
          {product.originalPrice && (
            <p className="text-xs text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</p>
          )}
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;
