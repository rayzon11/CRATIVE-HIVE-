import { Link } from "react-router-dom";
import { ArrowRight, Sparkles, Shield, Heart } from "lucide-react";
import { editorialStories } from "@/data/products";

const EditorialStories = () => (
  <section className="py-16 md:py-24 bg-secondary/30">
    <div className="container mx-auto px-4">
      <div className="text-center mb-10">
        <p className="text-xs font-semibold text-primary uppercase tracking-widest mb-2">Maker Stories</p>
        <h2 className="text-3xl md:text-4xl font-bold text-foreground">Stories from Our Makers</h2>
        <p className="text-muted-foreground mt-3 max-w-lg mx-auto text-sm">Every product has a story. Meet the artisans behind your favorite handmade goods.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {editorialStories.map((story, i) => (
          <Link
            key={story.id}
            to={`/seller/${story.sellerId}`}
            className="group relative overflow-hidden rounded-2xl aspect-[4/3] bg-secondary"
          >
            <img src={story.image} alt={story.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-5">
              <p className="text-xs text-primary-foreground/70 mb-1">{story.seller}</p>
              <h3 className="text-lg font-bold text-primary-foreground leading-tight">{story.title}</h3>
              <p className="text-sm text-primary-foreground/70 mt-1">{story.subtitle}</p>
              <span className="inline-flex items-center gap-1 text-xs text-primary mt-3 font-medium">
                Read story <ArrowRight size={12} />
              </span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  </section>
);

const TrustBanner = () => (
  <section className="py-12 bg-background border-t border-border">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
        {[
          { icon: Shield, title: "Buyer Protection", desc: "Every purchase is covered by our CraftHive Guarantee for complete peace of mind." },
          { icon: Heart, title: "Support Makers", desc: "100% of your purchase goes directly to independent artisans and small businesses." },
          { icon: Sparkles, title: "Handmade Quality", desc: "Every item is personally crafted by hand — no mass production, ever." },
        ].map(({ icon: Icon, title, desc }) => (
          <div key={title} className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Icon size={22} className="text-primary" />
            </div>
            <h3 className="font-bold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground max-w-xs">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const CtaBanner = () => (
  <>
    <EditorialStories />
    <TrustBanner />

    {/* Sell CTA */}
    <section className="py-16 md:py-24 bg-primary relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <img src="https://images.unsplash.com/photo-1529148482759-b35b25c5f217?w=1920&h=600&fit=crop" alt="" className="w-full h-full object-cover" />
      </div>
      <div className="container mx-auto px-4 relative z-10 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Ready to share your craft?</h2>
        <p className="text-primary-foreground/80 max-w-lg mx-auto mb-8">
          Join thousands of makers selling on CraftHive. Start free, upgrade when you're ready.
        </p>
        <Link
          to="/sell"
          className="inline-flex items-center gap-2 bg-primary-foreground text-primary px-8 py-4 rounded-full font-bold hover:bg-primary-foreground/90 transition-colors text-sm md:text-base"
        >
          Open your shop today <ArrowRight size={16} />
        </Link>
      </div>
    </section>
  </>
);

export default CtaBanner;
