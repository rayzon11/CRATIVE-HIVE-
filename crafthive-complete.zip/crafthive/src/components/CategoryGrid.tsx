import { Link } from "react-router-dom";
import { categories } from "@/data/products";
import { ArrowRight } from "lucide-react";

const CategoryGrid = () => {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold text-primary uppercase tracking-widest mb-2">Browse by</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Categories</h2>
          </div>
          <Link to="/categories" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
            View all <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-4">
          {categories.map((cat, i) => (
            <Link
              key={cat.slug}
              to={`/category/${cat.slug}`}
              className="group relative overflow-hidden rounded-2xl aspect-square bg-secondary hover:shadow-lg transition-all duration-300"
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <img
                src={cat.image}
                alt={cat.name}
                loading="lazy"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-sm md:text-base font-bold text-primary-foreground">{cat.name}</h3>
                <p className="text-xs text-primary-foreground/70 mt-0.5">{cat.count}</p>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-6 md:hidden">
          <Link to="/categories" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary">
            View all categories <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;
