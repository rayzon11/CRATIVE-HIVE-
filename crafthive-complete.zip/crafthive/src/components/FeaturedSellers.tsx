import { sellers } from "@/data/products";
import { Link } from "react-router-dom";
import { Star, ArrowRight, BadgeCheck } from "lucide-react";

const FeaturedSellers = () => {
  const proSellers = sellers.filter((s) => s.plan === "pro");

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold text-primary uppercase tracking-widest mb-2">Our makers</p>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Featured Sellers</h2>
          </div>
          <Link to="/sellers" className="hidden md:flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors">
            Meet all sellers <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {proSellers.map((seller) => (
            <Link
              key={seller.id}
              to={`/seller/${seller.id}`}
              className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
            >
              {/* Banner */}
              <div className="relative h-28 overflow-hidden bg-secondary">
                <img src={seller.banner} alt={seller.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
              </div>

              {/* Content */}
              <div className="px-5 pb-5 pt-0 -mt-8 relative">
                <div className="flex items-end justify-between mb-3">
                  <img
                    src={seller.avatar}
                    alt={seller.name}
                    className="w-16 h-16 rounded-2xl border-4 border-white object-cover shadow-sm"
                  />
                  <div className="flex items-center gap-1 bg-amber-50 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full border border-amber-200">
                    <Star size={11} className="fill-amber-400 text-amber-400" />
                    {seller.rating}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <h3 className="text-base font-bold text-foreground">{seller.name}</h3>
                  <BadgeCheck size={15} className="text-primary fill-primary/10" />
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{seller.specialty}</p>
                <p className="text-xs text-muted-foreground mt-3 line-clamp-2">{seller.bio}</p>

                <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border">
                  <div>
                    <p className="text-sm font-bold text-foreground">{seller.sales}</p>
                    <p className="text-xs text-muted-foreground">Sales</p>
                  </div>
                  <div>
                    <p className="text-sm font-bold text-foreground">{seller.location}</p>
                    <p className="text-xs text-muted-foreground">Location</p>
                  </div>
                  <div className="ml-auto">
                    <span className="text-xs font-medium text-primary">View shop →</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedSellers;
