# 🐝 CraftHive — Handmade & Creative Goods Marketplace

A full-stack, production-ready artisan marketplace built with React + TypeScript + Tailwind CSS + Supabase + Stripe.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Copy env template and fill in your keys
cp .env.example .env.local

# 3. Run the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## 🔑 Environment Variables

Create `.env.local`:

```env
# Supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key

# Stripe (publishable key only in frontend)
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_...

# Algolia (optional — for search)
VITE_ALGOLIA_APP_ID=your_app_id
VITE_ALGOLIA_SEARCH_KEY=your_search_key
```

Supabase Edge Function secrets (set in Supabase dashboard):
```
STRIPE_SECRET_KEY=sk_test_...
RESEND_API_KEY=re_...
```

---

## 📁 Project Structure

```
crafthive/
├── public/
│   ├── manifest.json          # PWA manifest
│   └── sw.js                  # Service worker (cache-first/network-first)
├── src/
│   ├── components/
│   │   ├── Navbar.tsx          # Sticky nav with search, cart, user menu
│   │   ├── HeroSection.tsx     # Full-width hero with search
│   │   ├── CategoryGrid.tsx    # 8-category image grid
│   │   ├── TrendingProducts.tsx
│   │   ├── FeaturedSellers.tsx # Pro-plan sellers spotlight
│   │   ├── ProductCard.tsx     # Reusable card (wishlist, badges, sale)
│   │   ├── FlashSaleBanner.tsx # Live countdown flash sale banner
│   │   ├── CookieConsent.tsx   # GDPR cookie banner
│   │   ├── Footer.tsx          # Newsletter + multi-column links
│   │   ├── PageLayout.tsx      # Shared layout wrapper
│   │   └── CtaBanner.tsx       # Editorial stories + sell CTA
│   ├── pages/
│   │   ├── Index.tsx           # Homepage
│   │   ├── ProductDetail.tsx   # Gallery, variants, reviews, seller card
│   │   ├── Trending.tsx        # Filterable product listing
│   │   ├── Search.tsx          # Search results
│   │   ├── Categories.tsx      # Category overview
│   │   ├── CategoryDetail.tsx  # Products by category
│   │   ├── Sellers.tsx         # All sellers grid
│   │   ├── SellerProfile.tsx   # Seller shop page with tabs
│   │   ├── Cart.tsx            # Cart with coupon/gift card/credits
│   │   ├── Wishlist.tsx        # Multiple wishlist collections
│   │   ├── Login.tsx           # Auth (email + Google)
│   │   ├── Account.tsx         # Buyer dashboard (orders, profile, referrals)
│   │   ├── SellerDashboard.tsx # Seller dashboard (overview, products, orders, revenue...)
│   │   ├── AdminPanel.tsx      # Admin panel (users, sellers, products, settings...)
│   │   ├── Sell.tsx            # Pricing & plan comparison
│   │   ├── About.tsx           # About page
│   │   └── NotFound.tsx        # 404 branded page
│   └── data/
│       └── products.ts         # Mock data with real Unsplash images
├── supabase/
│   ├── schema.sql              # Complete DB schema with RLS
│   └── functions/
│       ├── send-order-confirmation/  # Resend email on order
│       ├── send-shipping-update/     # Resend email with tracking
│       ├── send-gift-card/           # Gift card email
│       └── process-refund/           # Stripe refund via API
└── index.html                  # PWA-ready HTML with JSON-LD, OG tags
```

---

## 🗃️ Database Setup

1. Go to your Supabase project → SQL Editor
2. Run the contents of `supabase/schema.sql`
3. This creates all tables, RLS policies, triggers, indexes, and seeds default settings

---

## ⚡ Deploy Edge Functions

```bash
# Install Supabase CLI
npm install -g supabase

# Login and link project
supabase login
supabase link --project-ref your-project-ref

# Deploy all functions
supabase functions deploy send-order-confirmation
supabase functions deploy send-shipping-update
supabase functions deploy send-gift-card
supabase functions deploy process-refund

# Set secrets
supabase secrets set STRIPE_SECRET_KEY=sk_test_...
supabase secrets set RESEND_API_KEY=re_...
```

---

## 🎨 Design System

| Token | Value | Usage |
|---|---|---|
| Primary | `#D4522A` (terracotta) | CTAs, badges, links |
| Background | `#FAF7F2` (warm cream) | Page background |
| Text | `#1C1917` (deep charcoal) | Body text |
| Font | Plus Jakarta Sans | All text |

---

## 🔑 User Roles & Routes

| Role | Key Routes |
|---|---|
| **Buyer** | `/`, `/product/:id`, `/cart`, `/account`, `/wishlist` |
| **Seller** | `/seller` (dashboard) |
| **Admin** | `/admin` (panel — requires `role='admin'` in profiles table) |

**To make yourself admin:** In Supabase SQL editor:
```sql
UPDATE profiles SET role = 'admin' WHERE email = 'your@email.com';
```

---

## 💳 Stripe Integration

- **Checkout:** Stripe Elements (card, Apple Pay, Google Pay)
- **Seller payouts:** Stripe Connect (destination charges)
- **Subscriptions:** Stripe Billing Portal (Growth $9.99/mo, Pro $29.99/mo)
- **Promotions:** One-time charges for sponsored listings
- **Refunds:** Via Edge Function → `process-refund`

---

## 📱 PWA

The app is fully PWA-ready:
- `public/manifest.json` — name, icons, theme color
- `public/sw.js` — Workbox-style caching (cache-first static, network-first API, image cache)
- Push notifications wired for new messages, order updates, wishlisted item on sale

---

## 🛠️ Tech Stack

- **Frontend:** React 18, TypeScript, Vite
- **Styling:** Tailwind CSS, shadcn/ui
- **Backend:** Supabase (PostgreSQL, Auth, Storage, Realtime, Edge Functions)
- **Payments:** Stripe (Connect, Subscriptions, Elements)
- **Email:** Resend via Supabase Edge Functions
- **Search:** Algolia InstantSearch (optional)
- **PWA:** Custom service worker with Workbox-style strategies

---

## 📋 Feature Checklist

### Public Pages
- [x] Homepage (hero, categories, trending, sellers, editorial, CTA)
- [x] Flash sale banner with live countdown
- [x] Product listing / category pages
- [x] Product detail (gallery, variants, reviews, seller card, tabs)
- [x] Seller shop page (banner, tabs, products, reviews)
- [x] Search results page
- [x] Cookie consent banner

### Auth
- [x] Email/password signup & login
- [x] Google OAuth
- [x] Referral code on signup

### Cart & Checkout
- [x] Cart with seller grouping
- [x] Coupon code validation
- [x] Gift card application
- [x] Platform credits toggle
- [x] Stripe checkout (card, Apple/Google Pay)

### Buyer Dashboard
- [x] Profile management
- [x] Orders (track, cancel, review)
- [x] Wishlists (multiple collections, public/private)
- [x] Referrals & credits
- [x] Recently viewed

### Seller Dashboard
- [x] KPI overview with revenue chart
- [x] Product manager (CRUD, status, bulk)
- [x] Order manager (status updates, tracking)
- [x] Revenue & payout history
- [x] Coupons
- [x] Sponsored listings (promotions)
- [x] Subscription plans (Free/Growth/Pro)
- [x] Shop settings

### Admin Panel
- [x] Platform dashboard (KPIs, flagged content alerts)
- [x] User management (suspend, promote)
- [x] Seller management (approve, ban, plan override)
- [x] Product management (feature, remove, approve)
- [x] Reports (top sellers, products)
- [x] Platform settings (commission rates, referral rewards, toggles)

### Infrastructure
- [x] Complete Supabase schema (20 tables, full RLS)
- [x] 4 Edge Functions (order email, shipping email, gift card email, refund)
- [x] PWA manifest + service worker
- [x] SEO meta tags + JSON-LD + OG tags
- [x] Branded 404 page

---

*Built with ❤️ for artisans worldwide.*
