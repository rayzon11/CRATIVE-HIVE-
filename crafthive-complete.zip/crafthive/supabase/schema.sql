-- ============================================================
-- CraftHive — Complete Supabase Database Schema
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- PROFILES
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  role TEXT NOT NULL DEFAULT 'buyer' CHECK (role IN ('buyer','seller','admin')),
  full_name TEXT, email TEXT UNIQUE, avatar_url TEXT,
  referral_code TEXT UNIQUE DEFAULT substring(md5(random()::text),1,8),
  credits_balance NUMERIC(10,2) NOT NULL DEFAULT 0,
  plan TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free','growth','pro')),
  stripe_customer_id TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own profile" ON profiles FOR SELECT USING (auth.uid()=id);
CREATE POLICY "Users update own profile" ON profiles FOR UPDATE USING (auth.uid()=id);
CREATE POLICY "Admin all profiles" ON profiles FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));
CREATE OR REPLACE FUNCTION handle_new_user() RETURNS TRIGGER AS $$
BEGIN INSERT INTO profiles(id,email,full_name) VALUES(NEW.id,NEW.email,NEW.raw_user_meta_data->>'full_name'); RETURN NEW; END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- CATEGORIES
CREATE TABLE categories (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL,
  icon_url TEXT, parent_id UUID REFERENCES categories(id), is_visible BOOLEAN DEFAULT TRUE,
  sort_order INT DEFAULT 0, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads categories" ON categories FOR SELECT TO authenticated,anon USING (is_visible=TRUE);
CREATE POLICY "Admin manages categories" ON categories FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));
INSERT INTO categories(name,slug,sort_order) VALUES ('Jewelry','jewelry',1),('Art','art',2),('Home Decor','home-decor',3),('Clothing','clothing',4),('Vintage','vintage',5),('Pottery','pottery',6),('Candles','candles',7),('Craft Supplies','craft-supplies',8);

-- SHOPS
CREATE TABLE shops (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, owner_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, description TEXT, banner_url TEXT, avatar_url TEXT,
  location TEXT, policies TEXT, social_links JSONB DEFAULT '{}', rating_avg NUMERIC(3,2) DEFAULT 0,
  total_sales INT DEFAULT 0, stripe_connect_id TEXT, is_active BOOLEAN DEFAULT TRUE, is_suspended BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE shops ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads active shops" ON shops FOR SELECT TO authenticated,anon USING (is_active=TRUE AND is_suspended=FALSE);
CREATE POLICY "Owners manage shop" ON shops FOR ALL USING (auth.uid()=owner_id);
CREATE POLICY "Admin all shops" ON shops FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- PRODUCTS
CREATE TABLE products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, shop_id UUID REFERENCES shops(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL, description TEXT, price NUMERIC(10,2) NOT NULL, compare_at_price NUMERIC(10,2),
  category_id UUID REFERENCES categories(id), tags TEXT[] DEFAULT '{}', images TEXT[] DEFAULT '{}',
  stock INT NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('active','draft','flagged')),
  is_featured BOOLEAN DEFAULT FALSE, is_sponsored BOOLEAN DEFAULT FALSE, sponsor_expires_at TIMESTAMPTZ,
  meta_title TEXT, meta_description TEXT, weight NUMERIC(8,2), processing_days INT DEFAULT 3,
  views INT DEFAULT 0, sold_count INT DEFAULT 0, free_shipping BOOLEAN DEFAULT FALSE,
  shipping_cost NUMERIC(10,2) DEFAULT 0, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads active products" ON products FOR SELECT TO authenticated,anon USING (status='active');
CREATE POLICY "Sellers manage own products" ON products FOR ALL USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all products" ON products FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));
CREATE INDEX products_fts ON products USING GIN (to_tsvector('english', coalesce(title,'')||' '||coalesce(description,'')));
CREATE INDEX products_shop_idx ON products(shop_id);
CREATE INDEX products_category_idx ON products(category_id);
CREATE INDEX products_status_idx ON products(status);

-- PRODUCT VARIANTS
CREATE TABLE product_variants (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  option1_name TEXT, option1_value TEXT, option2_name TEXT, option2_value TEXT, option3_name TEXT, option3_value TEXT,
  price NUMERIC(10,2), stock INT DEFAULT 0, sku TEXT, image_url TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads variants" ON product_variants FOR SELECT TO authenticated,anon USING (TRUE);
CREATE POLICY "Sellers manage variants" ON product_variants FOR ALL USING (product_id IN (SELECT id FROM products WHERE shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid())));

-- ORDERS
CREATE TABLE orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, buyer_id UUID REFERENCES profiles(id) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','shipped','delivered','cancelled','refunded')),
  total NUMERIC(10,2) NOT NULL, commission_amount NUMERIC(10,2) DEFAULT 0, net_to_sellers NUMERIC(10,2) DEFAULT 0,
  coupon_code TEXT, discount_amount NUMERIC(10,2) DEFAULT 0, gift_card_code TEXT, gift_card_deduction NUMERIC(10,2) DEFAULT 0,
  credits_used NUMERIC(10,2) DEFAULT 0, shipping_address JSONB NOT NULL DEFAULT '{}',
  stripe_payment_intent TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Buyers see own orders" ON orders FOR SELECT USING (auth.uid()=buyer_id);
CREATE POLICY "Buyers create orders" ON orders FOR INSERT WITH CHECK (auth.uid()=buyer_id);
CREATE POLICY "Admin all orders" ON orders FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- ORDER ITEMS
CREATE TABLE order_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, order_id UUID REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES products(id) NOT NULL, shop_id UUID REFERENCES shops(id) NOT NULL,
  variant_id UUID REFERENCES product_variants(id), quantity INT NOT NULL DEFAULT 1,
  unit_price NUMERIC(10,2) NOT NULL, shipping_cost NUMERIC(10,2) DEFAULT 0, shipping_carrier TEXT,
  tracking_number TEXT, estimated_delivery DATE,
  item_status TEXT NOT NULL DEFAULT 'pending' CHECK (item_status IN ('pending','processing','shipped','delivered','cancelled','refunded')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Buyers see own items" ON order_items FOR SELECT USING (order_id IN (SELECT id FROM orders WHERE buyer_id=auth.uid()));
CREATE POLICY "Sellers see shop items" ON order_items FOR SELECT USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Sellers update items" ON order_items FOR UPDATE USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all order items" ON order_items FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- REVIEWS
CREATE TABLE reviews (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  buyer_id UUID REFERENCES profiles(id) NOT NULL, order_id UUID REFERENCES orders(id) NOT NULL,
  rating INT NOT NULL CHECK (rating>=1 AND rating<=5), body TEXT CHECK (length(body)>=20),
  photos TEXT[] DEFAULT '{}', video_url TEXT, helpful_yes INT DEFAULT 0, helpful_no INT DEFAULT 0,
  seller_reply TEXT, is_hidden BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (buyer_id,order_id,product_id)
);
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads visible reviews" ON reviews FOR SELECT TO authenticated,anon USING (is_hidden=FALSE);
CREATE POLICY "Buyers create reviews" ON reviews FOR INSERT WITH CHECK (auth.uid()=buyer_id);
CREATE POLICY "Sellers reply" ON reviews FOR UPDATE USING (product_id IN (SELECT id FROM products WHERE shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid())));
CREATE POLICY "Admin all reviews" ON reviews FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- WISHLISTS
CREATE TABLE wishlists (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, buyer_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL, name TEXT NOT NULL DEFAULT 'My Wishlist', is_public BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE wishlist_items (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, wishlist_id UUID REFERENCES wishlists(id) ON DELETE CASCADE NOT NULL, product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW(), UNIQUE(wishlist_id,product_id));
ALTER TABLE wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlist_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Buyers manage wishlists" ON wishlists FOR ALL USING (auth.uid()=buyer_id);
CREATE POLICY "Public wishlists readable" ON wishlists FOR SELECT TO authenticated,anon USING (is_public=TRUE);
CREATE POLICY "Buyers manage wishlist items" ON wishlist_items FOR ALL USING (wishlist_id IN (SELECT id FROM wishlists WHERE buyer_id=auth.uid()));

-- MESSAGES
CREATE TABLE messages (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, shop_id UUID REFERENCES shops(id) NOT NULL, buyer_id UUID REFERENCES profiles(id) NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW(), UNIQUE(shop_id,buyer_id));
CREATE TABLE message_items (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, message_id UUID REFERENCES messages(id) ON DELETE CASCADE NOT NULL, sender_id UUID REFERENCES profiles(id) NOT NULL, body TEXT, image_url TEXT, is_read BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Participants see threads" ON messages FOR SELECT USING (auth.uid()=buyer_id OR shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Participants create threads" ON messages FOR INSERT WITH CHECK (auth.uid()=buyer_id);
CREATE POLICY "Participants see messages" ON message_items FOR SELECT USING (message_id IN (SELECT id FROM messages WHERE buyer_id=auth.uid() OR shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid())));
CREATE POLICY "Participants send messages" ON message_items FOR INSERT WITH CHECK (auth.uid()=sender_id);
ALTER PUBLICATION supabase_realtime ADD TABLE message_items;

-- COUPONS
CREATE TABLE coupons (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, shop_id UUID REFERENCES shops(id), code TEXT UNIQUE NOT NULL, type TEXT NOT NULL CHECK (type IN ('percent','fixed')), value NUMERIC(10,2) NOT NULL, min_order NUMERIC(10,2) DEFAULT 0, max_uses INT, used_count INT DEFAULT 0, expires_at TIMESTAMPTZ, is_active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Validate coupons" ON coupons FOR SELECT TO authenticated,anon USING (is_active=TRUE);
CREATE POLICY "Sellers manage coupons" ON coupons FOR ALL USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all coupons" ON coupons FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- NOTIFICATIONS
CREATE TABLE notifications (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL, type TEXT NOT NULL, title TEXT NOT NULL, body TEXT, link TEXT, is_read BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own notifications" ON notifications FOR SELECT USING (auth.uid()=user_id);
CREATE POLICY "Users update own notifications" ON notifications FOR UPDATE USING (auth.uid()=user_id);
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- PROMOTIONS
CREATE TABLE promotions (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL, shop_id UUID REFERENCES shops(id) NOT NULL, days INT NOT NULL, cost NUMERIC(10,2) NOT NULL, impressions INT DEFAULT 0, clicks INT DEFAULT 0, stripe_charge_id TEXT, starts_at TIMESTAMPTZ DEFAULT NOW(), expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE promotions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Sellers see promotions" ON promotions FOR SELECT USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Sellers create promotions" ON promotions FOR INSERT WITH CHECK (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all promotions" ON promotions FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- FLASH SALES
CREATE TABLE flash_sales (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, name TEXT NOT NULL, banner_url TEXT, starts_at TIMESTAMPTZ NOT NULL, ends_at TIMESTAMPTZ NOT NULL, is_active BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE flash_sale_items (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, flash_sale_id UUID REFERENCES flash_sales(id) ON DELETE CASCADE NOT NULL, product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL, discount_percent INT NOT NULL CHECK (discount_percent>0 AND discount_percent<=90), UNIQUE(flash_sale_id,product_id));
ALTER TABLE flash_sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE flash_sale_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads active flash sales" ON flash_sales FOR SELECT TO authenticated,anon USING (is_active=TRUE);
CREATE POLICY "Anyone reads flash items" ON flash_sale_items FOR SELECT TO authenticated,anon USING (TRUE);
CREATE POLICY "Admin manages flash sales" ON flash_sales FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));
CREATE POLICY "Sellers opt into flash sales" ON flash_sale_items FOR INSERT WITH CHECK (product_id IN (SELECT id FROM products WHERE shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid())));

-- GIFT CARDS
CREATE TABLE gift_cards (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, code TEXT UNIQUE NOT NULL DEFAULT upper(substring(md5(random()::text),1,4)||'-'||substring(md5(random()::text),1,4)), amount NUMERIC(10,2) NOT NULL, remaining NUMERIC(10,2) NOT NULL, purchased_by UUID REFERENCES profiles(id), recipient_email TEXT, stripe_charge_id TEXT, is_active BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE gift_cards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Purchasers see gift cards" ON gift_cards FOR SELECT USING (auth.uid()=purchased_by);
CREATE POLICY "Validate gift cards" ON gift_cards FOR SELECT TO authenticated USING (is_active=TRUE AND remaining>0);
CREATE POLICY "Admin all gift cards" ON gift_cards FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- REFERRALS
CREATE TABLE referrals (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, referrer_id UUID REFERENCES profiles(id) NOT NULL, referred_id UUID REFERENCES profiles(id) NOT NULL, type TEXT NOT NULL CHECK (type IN ('buyer','seller')), credit_amount NUMERIC(10,2) NOT NULL DEFAULT 0, is_paid BOOLEAN DEFAULT FALSE, created_at TIMESTAMPTZ DEFAULT NOW(), UNIQUE(referrer_id,referred_id));
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own referrals" ON referrals FOR SELECT USING (auth.uid()=referrer_id);
CREATE POLICY "Admin all referrals" ON referrals FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- SHOP SUBSCRIPTIONS
CREATE TABLE shop_subscriptions (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, shop_id UUID REFERENCES shops(id) ON DELETE CASCADE NOT NULL, plan TEXT NOT NULL CHECK (plan IN ('free','growth','pro')), stripe_subscription_id TEXT, current_period_end TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE shop_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Sellers see own sub" ON shop_subscriptions FOR SELECT USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all subs" ON shop_subscriptions FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- PAYOUTS
CREATE TABLE payouts (id UUID DEFAULT uuid_generate_v4() PRIMARY KEY, shop_id UUID REFERENCES shops(id) NOT NULL, amount NUMERIC(10,2) NOT NULL, commission NUMERIC(10,2) NOT NULL DEFAULT 0, net NUMERIC(10,2) NOT NULL, stripe_payout_id TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE payouts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Sellers see own payouts" ON payouts FOR SELECT USING (shop_id IN (SELECT id FROM shops WHERE owner_id=auth.uid()));
CREATE POLICY "Admin all payouts" ON payouts FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));

-- PLATFORM SETTINGS
CREATE TABLE platform_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMPTZ DEFAULT NOW());
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads settings" ON platform_settings FOR SELECT TO authenticated,anon USING (TRUE);
CREATE POLICY "Admin manages settings" ON platform_settings FOR ALL USING (EXISTS (SELECT 1 FROM profiles WHERE id=auth.uid() AND role='admin'));
INSERT INTO platform_settings(key,value) VALUES ('commission_free','8'),('commission_growth','5'),('commission_pro','3'),('referral_buyer_credit','2'),('referral_seller_credit','5'),('min_payout_threshold','25'),('max_sponsored_slots','3'),('ads_enabled','true'),('maintenance_mode','false'),('site_name','CraftHive'),('growth_plan_price','9.99'),('pro_plan_price','29.99');

-- UTILITY FUNCTIONS
CREATE OR REPLACE FUNCTION get_commission_rate(p_shop_id UUID) RETURNS NUMERIC AS $$
DECLARE v_plan TEXT; v_rate NUMERIC;
BEGIN
  SELECT p.plan INTO v_plan FROM shops s JOIN profiles p ON s.owner_id=p.id WHERE s.id=p_shop_id;
  SELECT value::NUMERIC INTO v_rate FROM platform_settings WHERE key='commission_'||COALESCE(v_plan,'free');
  RETURN COALESCE(v_rate,8)/100;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION increment_product_views(p_product_id UUID) RETURNS VOID AS $$
  UPDATE products SET views=views+1 WHERE id=p_product_id;
$$ LANGUAGE sql SECURITY DEFINER;
