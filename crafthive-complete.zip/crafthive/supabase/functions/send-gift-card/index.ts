import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
serve(async (req) => {
  const { recipient_email, code, amount } = await req.json();
  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({
      from: "CraftHive <gifts@crafthive.com>",
      to: recipient_email,
      subject: `You received a $${amount} CraftHive Gift Card! 🎁`,
      html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;text-align:center">
        <h1 style="color:#D4522A">You've got a Gift Card! 🎉</h1>
        <p>Someone special sent you a CraftHive gift card.</p>
        <div style="background:#FAF7F2;border:2px dashed #D4522A;border-radius:16px;padding:32px;margin:24px 0">
          <p style="font-size:48px;font-weight:bold;color:#D4522A;margin:0">$${amount}</p>
          <p style="font-size:24px;font-family:monospace;letter-spacing:4px;margin-top:12px;color:#1C1917">${code}</p>
        </div>
        <p>Apply this code at checkout on <a href="https://crafthive.com">crafthive.com</a></p>
        <p style="font-size:12px;color:#888">Valid for one-time use. Partial redemption supported.</p>
      </div>`,
    }),
  });
  return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
});
