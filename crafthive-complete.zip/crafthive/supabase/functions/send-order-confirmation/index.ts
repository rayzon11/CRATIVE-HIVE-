import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

serve(async (req) => {
  const { order, buyer } = await req.json();

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${RESEND_API_KEY}`,
    },
    body: JSON.stringify({
      from: "CraftHive <orders@crafthive.com>",
      to: buyer.email,
      subject: `Order Confirmed — ${order.id}`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
          <h1 style="color:#D4522A">Your order is confirmed! 🎉</h1>
          <p>Hi ${buyer.full_name},</p>
          <p>Thank you for your order <strong>${order.id}</strong>. We've notified your seller(s) and they'll get started soon.</p>
          <h3>Order Total: $${order.total}</h3>
          <a href="https://crafthive.com/account" style="background:#D4522A;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block;margin-top:16px">View Order</a>
          <p style="margin-top:32px;color:#888;font-size:12px">CraftHive · Where handmade meets the world</p>
        </div>
      `,
    }),
  });

  return new Response(JSON.stringify({ ok: res.ok }), {
    headers: { "Content-Type": "application/json" },
  });
});
