import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const CARRIER_URLS: Record<string,string> = {
  DHL: "https://www.dhl.com/en/express/tracking.html?AWB=",
  FedEx: "https://www.fedex.com/fedextrack/?trknbr=",
  UPS: "https://www.ups.com/track?tracknum=",
  USPS: "https://tools.usps.com/go/TrackConfirmAction?tLabels=",
};

serve(async (req) => {
  const { order, buyer, carrier, tracking_number, estimated_delivery } = await req.json();
  const trackUrl = (CARRIER_URLS[carrier] || "#") + tracking_number;

  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({
      from: "CraftHive <orders@crafthive.com>",
      to: buyer.email,
      subject: `Your order ${order.id} is on its way! 📦`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px">
          <h1 style="color:#D4522A">Your order has shipped!</h1>
          <p>Hi ${buyer.full_name}, great news — your order is on the way.</p>
          <table style="border:1px solid #eee;border-radius:8px;padding:16px;width:100%">
            <tr><td><strong>Carrier:</strong></td><td>${carrier}</td></tr>
            <tr><td><strong>Tracking:</strong></td><td><a href="${trackUrl}">${tracking_number}</a></td></tr>
            <tr><td><strong>Est. Delivery:</strong></td><td>${estimated_delivery}</td></tr>
          </table>
          <a href="${trackUrl}" style="background:#D4522A;color:white;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block;margin-top:16px">Track Your Package</a>
        </div>
      `,
    }),
  });

  return new Response(JSON.stringify({ ok: true }), { headers: { "Content-Type": "application/json" } });
});
