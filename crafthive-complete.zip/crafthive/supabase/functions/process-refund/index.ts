import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.0.0";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, { apiVersion: "2023-10-16" });

serve(async (req) => {
  const { payment_intent_id, amount, reason } = await req.json();
  try {
    const refund = await stripe.refunds.create({
      payment_intent: payment_intent_id,
      ...(amount ? { amount: Math.round(amount * 100) } : {}),
      reason: reason || "requested_by_customer",
    });
    return new Response(JSON.stringify({ ok: true, refund_id: refund.id }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ ok: false, error: err.message }), {
      status: 400, headers: { "Content-Type": "application/json" },
    });
  }
});
